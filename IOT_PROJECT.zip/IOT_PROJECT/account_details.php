<?php
   require("includes/connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
      $email = null;
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       $sel = "SELECT * FROM users WHERE user_id= '$id'";
       $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
       $row= mysqli_fetch_array($sel1);
       $users_interest = $row['user_interest'];
       $users_bio = $row['user_bio'];
       if( $users_interest == null){
           echo ("<script>location.href='user_interest_form.php'</script>");
       } elseif ($users_bio == null) {
       echo ("<script>location.href='user_bio_form.php'</script>");
   }
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <script type="text/javascript" src="design\js\validation.js"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Account Details | Forumex</title>
      <style>
              #loads{
               background: url('design/image/Forumex Loading.gif') no-repeat center center;
               position: absolute;
               top: 0;
               left: 0;
               height: 100%;
               width: 100%;
               z-index: 9999999;
          }
         .modal-header{
         border-bottom: 1px solid #EBEBEB;
         color:rgb(255,255,255); 
         background-color: #3333FF; 
         }
         .close{
         color:rgb(0,0,0);
         font-weight: bold;
         font-size:50px;
         }
         form {
         position: relative;
         width: 200px;
         }
         input{
         text-align: center;
         }
         .user_profile{
            
         }
         @media(min-width:300px){
             .show_data{
                  padding-top:0px;
             }
         }
          @media(min-width:500px){
             .show_data{
                  padding-top:40px;
             }
         }
      </style>
   </head>
   <body style="padding-top: 100px; background-color:rgb(255,255,255);">
      <?php
         require 'includes/home_header.php';
          ?>
        <div id="loads"></div>
       <div class="container" id="data" style="font-family: 'Arial,sans-serif';">
         <div class="row zoom">
             <div class="col-xs-12">
              <?php if(isset($_GET['user_id'])){
                  $sel = "SELECT * FROM users WHERE user_id= '".$_GET['user_id']."' AND user_status='Active'";
                  $sel2 = mysqli_query($con, $sel) or die(mysqli_error($con));
                  $row= mysqli_num_rows($sel2);
                  if($row == 0){ ?>
                                            <div class="container" style="paddin-top:100px;">
                          <div class="row">
                              <div class="col-xs-12" style="">
                                  <center>
                                  <img src="design/image/emoj.gif" style="width: 50%; padding: 0px;height: 100%; margin: 0px;" alt=""/>
                                  <h1>Oops! No User Found</h1>
                                  </center>
                              </div>
                          </div>
                      </div>
                 <?php } else{ 
                     $num = mysqli_fetch_array($sel2);
                     $users_name = $num['user_name'];
                     $users_email = $num['user_email'];
                     $user_interest = $num['user_interest'];
                     $userbio = $num['user_bio'];
                     $user_location = $num['user_country'];
                     $user_profile = $num['profile'];
                     require 'user_profile.php';
                     ?>
                      <div class="row show_data">
                          <?php 
                                require 'user_details.php'; 
                                require 'user_profile_picture.php'; 
                                require 'user_bio.php'; 
                           ?>
                      </div>
                   <?php    }
                     ?>
               <?php      
                 } else { ?>
                      <div class="container" style="paddin-top:100px;">
                          <div class="row">
                              <div class="col-xs-12" style="">
                                  <center>
                                  <img src="design/image/emoj.gif" style="width: 50%; padding: 0px;height: 100%; margin: 0px;" alt=""/>
                                  <h1>Oops! No User Found</h1>
                                  </center>
                              </div>
                          </div>
                      </div>
               <?php  }
                  ?>
             </div>
            <?php include 'account_help.php'; ?>
             
         </div>
       </div>
   </body>
<?php 
    if(isset($_SESSION['user_email']) && isset($_SESSION['user_email']) == isset($num['user_email'])){
?>
        <style>
            .change{
                    display: none;
                    color: rgb(0,0,0);
            }
            .change_show:hover .change,.change_show:active .change{
                display: inline-block;
            }
        </style>
<?php } ?>
</html>
<script type="text/javascript" src="design\js\form_animation.js"></script>
<script type="text/javascript" src="design\js\page_animation.js"></script>
<script>
   $(document).ready(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
  document.getElementById("loads").style.display="block";
  document.getElementById("data").style.display="none";
  setTimeout("hide()", 2000);
});
function hide() {
    document.getElementById("loads").style.display="none";
    document.getElementById("data").style.display="block";
}

</script> 
