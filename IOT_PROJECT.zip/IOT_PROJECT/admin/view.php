<?php
   require("admin_connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:../login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       if($email != "admin@fourmex.com"){
           header('Location:../home.php');
       }
        $error = null;
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="..\design\css\bootstrap.css">
      <script type="text/javascript" src="..\design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="..\design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="..\design\css\animate.min.css">
      <script type="text/javascript" src="..\design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="style_admin.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Admin | Forumex</title>
      <style>
          .content{
         min-height: 300px;
         padding-top: 20px;
         padding-bottom: 20px;
         }
         .quest{
         margin: 10px;
         padding: 10px;
         width: 100%;
         border: 1px solid rgb(0,0,0);
         }
          .zoom{
                opacity: 0;
            }
            .zoom.animate__zoomIn{
                opacity: 1;
                animation-duration: 1s;
            }
      </style>
   </head>
   <body>
      <?php
         require 'header_admin.php';
         ?>
      <div class="container" style="padding-top:50px;">
         <div class="row zoom">
            <?php if(isset($_GET['survey-id'])){ 
                $sidd = $_GET['survey-id'];
                $sel = "select * from survey_main where survey_id=$sidd";
                $sel = mysqli_query($con_survey, $sel) or die(mysqli_error($con_survey));
                if(mysqli_num_rows($sel) == 1 ){ 
                    $s = mysqli_fetch_array($sel);
                    $survey_title = $s['survey_heading'];
                    $survey_questions_count = $s['total_question'];
                    if($survey_questions_count != 0){ 
                        $sel = "select * from survey_questions where survey_id=$sidd";
                $sel = mysqli_query($con_survey, $sel) or die(mysqli_error($con_survey));
                $count = 0; ?>
             <a href="admin_index.php" style="color:rgb(0,0,0);">Go Back</a>
             <h1 style="margin-top:0px;">View <?php echo $survey_title;?> Survey</h1>
             <div class="col-xs-12 col-sm-offset-2 col-sm-8" style="padding-bottom:20px;">
                <?php while ($result= mysqli_fetch_array($sel)){
                     $count++;
                            $survey_question = $result['survey_question'];
                            $survey_opt1 = $result['opt1'];
                            $survey_opt2 = $result['opt2'];
                            $survey_opt3 = $result['opt3'];
                            $survey_opt4 = $result['opt4']; ?>
           
             <div class="quest">
                        <p><?php echo $count . " . " . $survey_question; ?></p>
                        <ul>
                            <li><?php echo $survey_opt1; ?></li>
                            <li><?php echo $survey_opt2; ?></li>
                            <li><?php echo $survey_opt3; ?></li>
                            <li><?php echo $survey_opt4; ?></li>
                        </ul>
                     </div>
                <?php  }
                ?>
                   <center><a href="admin_index.php" style="padding-top:20px;color:rgb(0,0,0);">Go Back</a></center>
                      </div>
                  <?php  } else { ?>
 <div class="col-xs-12">
                 <center>
                     <h1>Oops!<?php echo $survey_title ?> Survey<br> Has No Questions</h1>
                 </center>
             </div>
<?php }
                    ?>
                    
              <?php  } else { ?>
                  <div class="col-xs-12">
                 <center>
                     <h1>Oops! No Survey Found</h1>
                 </center>
             </div>
            <?php  }
                ?>
             
            <?php } else { ?>
             <div class="col-xs-12">
                 <center>
                     <h1>Oops! No Survey Found</h1>
                 </center>
             </div>
            <?php } ?>
         </div>
      </div>
   </body>
</html>
<script>
   $(document).ready(function () {
        $('.zoom').waypoint(function (direction) {
            $('.zoom').addClass('animate__zoomIn');
        }, {
            offset: '100%'
        });
    });
</script>