<?php
session_start();
 require("admin_connection.php");
if(isset($_SESSION['user_email'])){
    $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       if($email != "admin@fourmex.com"){
           header('Location:../home.php');
       }
}
if(isset($_GET['status']) && isset($_GET['id'])){
    $survey_id = $_GET['id'];
    if($_GET['status'] == 'Active'){
        $update = "update survey_main set survey_status = 'Inactive' where survey_id = '$survey_id'";
        $update = mysqli_query($con_survey, $update);
        if($update){
       header('location:admin_index.php');
   } else {
       echo "<script>alert('Something Went Wrong')</script>";
       echo "<script>location.href='admin_index.php'</script>";
   }
    } elseif ($_GET['status'] == 'Inactive') {
        $update = "update survey_main set survey_status = 'Active' where survey_id = '$survey_id'";
        $update = mysqli_query($con_survey, $update);
         if($update){
       header('location:admin_index.php');
   } else {
       echo "<script>alert('Something Went Wrong')</script>";
       echo "<script>location.href='admin_index.php'</script>";
   }
}
}
