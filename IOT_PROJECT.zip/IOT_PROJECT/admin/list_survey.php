<div class="col-xs-12 col-sm-8" style="padding-top:10px;">
    <div class="panel right" style="min-height: 300px;height:auto;">
        <div class="panel-heading">
            <h4>List of Survey</h4>
        </div>
        <div class="panel-body">
            <center>
                <div style="overflow-x:auto;">
                    <?php $select_survey_list = "select * from survey_main where survey_visibility = 'View'";
                          $result = mysqli_query($con_survey, $select_survey_list)or die(mysqli_error($con_survey));
                    ?>
                    <table id="surveyyy">
                        <thead>
                            <tr style="border-bottom: 1px solid black;">
                                <th>ID</th>
                                <th>Survey Title</th>
                                <th>Response Limit</th>
                                <th>Response Received</th>
                                <th>
                                    <select class="survey_status" data-attribute="class" style="padding:5px; width: auto; border: none;">
                                        <option value="all">Status</option>
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </select>
                                </th>
                                <th>Total Question</th>
                                <th>Points</th>
                                <th>Edit</th>
                                <th style="border-right: 0px ;">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                 $count = 0;
                                    while ($result_survey = mysqli_fetch_array($result)) {
                                        $survey_id_page = $result_survey['survey_id'];
                                        $survey_title_page = $result_survey['survey_heading'];
                                        $survey_response_page = $result_survey['survey_response'];
                                        $survey_response_received = $result_survey['survey_response_received'];
                                        $survey_status_page = $result_survey['survey_status']; 
                                        $survey_point = $result_survey['survey_point'];
                                        $survey_questions_count = $result_survey['total_question'];
                                        $count = $count+1;?>
                            <tr class="survey_list">
                                <td><?php echo $count ?></td>
                                <td class="links"><a href="view.php?survey-id=<?php echo $survey_id_page ?>"><?php echo $survey_title_page; ?></a></td>
                                <td><?php echo $survey_response_page; ?></td>
                                <td style="color: rgb(0,0,0);"><?php echo $survey_response_received; ?></td>
                                <td class="links"><a href="status.php?status=<?php echo $survey_status_page; ?>&id=<?php echo $survey_id_page;?>"><?php echo $survey_status_page; ?></a></td>
                                <td><?php echo $survey_questions_count; ?></td>
                                <td><?php echo $survey_point; ?></td>
                                <td class="links"><a href="#edit_modal" data-toggle="modal" data-survey-id="<?php echo $survey_id_page.','.$survey_title_page.','.$survey_response_page.','.$survey_point; ?>">Edit</a></td>
                                <td class="links" style="border-right: 0px ;"><a href="delete.php?id=<?php echo $survey_id_page;?>">Delete</a></td>
                            </tr>
                                 <?php } ?>
                        </tbody>
                    </table>
                </div>
            </center>
        </div>
    </div>
</div>
<?php 
      require 'edit.php'; 
?>
<script>
    $('#edit_modal').on('show.bs.modal', function(e) {
    var survey = $(e.relatedTarget).data('survey-id');
    var survey_details = survey.split(",");
    $(e.currentTarget).find('input[name="survey_ids"]').val(survey_details[0]);
    $(e.currentTarget).find('input[name="survey_names"]').val(survey_details[1]);
    $(e.currentTarget).find('input[name="survey_response_limit"]').val(survey_details[2]);
    $(e.currentTarget).find('input[name="survey_points"]').val(survey_details[3]);
});
       $(document).ready(function () {
   $(".survey_status").on("change", function () {
       searchterm = $(this).val();
         
       $('#surveyyy tbody tr').each(function () {
            
           var sel = $(this);
           var txt = sel.find('td:eq(4)').text();
           if (searchterm != 'all') {
   
   
               if (txt.indexOf(searchterm) === -1) {
                   $(this).hide();
               }
               else {
                   $(this).show();
               }
           }
           else
           {                       
               $('#surveyyy tbody tr').show();
           }
       });
   });
   });
</script>   