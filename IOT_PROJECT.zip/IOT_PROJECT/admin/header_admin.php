<style>
   .nav>li>a{
   color: rgb(0,0,0);
   }
   .nav>li>a:focus, .nav>li>a:hover{
   text-decoration: none;
   background-color: rgba(0,0,0,0.2);
   background-size: 50px;
   margin-top: 5px; margin-bottom: 5px;
   padding-top: 5px; 
   border-radius: 100px;
   color: rgb(255,255,255);
   text-shadow: 5px 5px rgb(0,0,0,0.2);
   }
   .icon-bar{
   background-color: rgb(255,255,255);
   }
</style>
<div class="navbar" style=" border: 0; box-shadow: 10px 5px 5px 5px rgba(0,0,0,0.2);">
   <div class="container">
      <div class="navbar-header">
         <button type="button" class="navbar-toggle" style="background-color: rgb(0,0,0,0.2);" data-toggle="collapse" data-target="#myNavbar">
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>                        
         </button>
          <b><a class="navbar-brand" style="font-size:36px; color: black; text-shadow: 3px 3px rgb(0,0,0,0.2)" href="admin_index.php">Forumex</a></b>
      </div>
      <div class="collapse navbar-collapse" style="border:0" id="myNavbar">
         <ul class="nav navbar-nav navbar-right">
            <li><a href = "../logout_script.php"><span class = "glyphicon glyphicon-log-in"></span> Logout</a></li>
         </ul>
      </div>
   </div>
</div>