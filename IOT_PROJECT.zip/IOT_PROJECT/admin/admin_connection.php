<?php
$con_survey = mysqli_connect("localhost", "root", "", "admin_fourmex", "3308") or die(mysqli_error($con));
?>