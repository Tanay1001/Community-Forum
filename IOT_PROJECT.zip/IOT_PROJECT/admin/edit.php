   <div class="modal fade" id="edit_modal">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Editing Survey</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                        <form id="my-form" method="POST" >
                           <div class="txtb" style="display:none;">
                              <label for="survey_ids">Survey Id</label><br>
                              <input type="number" name="survey_ids" id="survey_ids"  value="" required>
                              <span></span>
                           </div>
                           <div class="txtb">
                              <label for="survey_names">Survey Title</label><br>
                              <input class="focus" type="text" name="survey_names" id="survey_names" value="" required>
                              <span></span>
                           </div>
                           <div class="txtb">
                              <label for="survey_points">Survey Points</label><br>
                              <input class="focus" type="number" name="survey_points" id="survey_points"  value="" required min=100>
                              <span></span>
                           </div>
                           <div class="txtb">
                              <label for="survey_response_limit">Survey Response Limit</label><br>
                              <input class="focus" type="number" name="survey_response_limit" id="survey_response_limit" value="" min=100 required>
                              <span></span>
                           </div>
                           <div class="txtb">
                              <label for="survey_question">Total Number Of Question</label><br>
                              <input type="number" name="survey_question" id="survey_question"  min=3 required>
                              <span></span>
                           </div>
                           <div style="text-align: center">
                              <center> <input type="submit" id="next_survey" name="next_survey" class="logbtn" value="Next"> </center>
                           </div>
                        </form>
               </center>
            </div>
         </div>
      </div>
   </div>
<?php
   if(isset($_POST['next_survey'])){
       $s_id = $_POST['survey_ids'];
       $s_id = mysqli_real_escape_string($con_survey, $s_id);
       $s_names = $_POST['survey_names'];
       $s_names = mysqli_real_escape_string($con_survey, $s_names);
       $s_point = $_POST['survey_points'];
       $s_point = mysqli_real_escape_string($con_survey, $s_point);
       $s_response = $_POST['survey_response_limit'];
       $s_response = mysqli_real_escape_string($con_survey, $s_response);
       $s_ques = $_POST['survey_question'];
       $s_ques = mysqli_real_escape_string($con_survey, $s_ques);
       if($s_id != ""){
           if($s_names != ""){
               if($s_point >= 100){
                   if($s_response >= 100){
                       if($s_ques >= 3){
                           $sel = "SELECT survey_id,survey_heading FROM survey_main WHERE survey_id='" . $s_id . "' AND survey_heading='" . $s_names . "'";
                           $result = mysqli_query($con_survey, $sel)or die(mysqli_error($sel));
                           $num = mysqli_num_rows($result);
                           if($num > 0){
                               $sel = "update survey_main SET survey_response = '".$s_response."', survey_point = '".$s_point."',total_question = '".$s_ques."'  where survey_id = '" . $s_id. "'";
                               $result = mysqli_query($con_survey, $sel)or die(mysqli_error($sel));
                               if($result){
                                   $_SESSION['s_id'] = $s_id;
                                   $_SESSION['s_count'] = $s_ques;
      			        echo ("<script>location.href='add_question.php'</script>");
                               }
                           } else{
                               echo "<script>alert('Survey Not Found')</script>";
                           }
                       } else {
                           echo "<script>alert('Total Number Of Question should be greater than or equal to 10')</script>";
                       }
                   } else {
                        echo "<script>alert('Response Limit Should be greater than or equal to 100')</script>";
                   }
               } else {
                   echo "<script>alert('Points Should be greater than or equal to 100')</script>";
               }
           } else {
               echo "<script>alert('Not Valid Title')</script>";
           }
       } else {
           echo "<script>alert('Not Valid Id')</script>";
       } 
   }
   ?>