<?php
   require("admin_connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:../login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       if($email != "admin@fourmex.com"){
           header('Location:../home.php');
       }
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="..\design\css\bootstrap.css">
      <script type="text/javascript" src="..\design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="..\design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="..\design\css\animate.min.css">
      <script type="text/javascript" src="..\design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="style_admin.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Admin | Forumex</title>
      <style>
         .panel{
         width: 100%;
         height: auto;
         border-radius: 10px;
         box-shadow: 0px 0px 20px 10px rgba(0,0,0,0.2);
         }
         form{
         position: relative;
         width: 70%;
         }
         input{
         text-align: center;
         width: 100%;
         }
      </style>
   </head>
   <body>
    <?php if(isset($_SESSION['s_id']) && isset($_SESSION['s_count'])){ ?>
      <div class="container" style="padding-top:50px; padding-bottom: 50px;">
         <div class="row">
            <div class="col-xs-12 col-sm-offset-2  col-sm-8">
               <div class="panel">
                   <div class="panel-heading" style="border-bottom:1px solid rgba(0,0,0,0.2);">
                        <center>
                           <h3>Adding Questions</h3>
                        </center>  
                   </div>
                   <div class="panel-body">
                       <center>
                           <form id="my-form" method="POST">
                               <?php for($i = 1; $i <= $_SESSION['s_count']; $i++) { ?>
                               <div style="border:1px solid rgb(0,0,0); width: 100%;margin: 5px; padding: 25px;">
                               <div class="txtb" style="width:100%;">
                                    <label for="survey_questionn<?php echo $i; ?>">Question <?php echo $i; ?></label><br>
                                    <input type="text" name="survey_questionn<?php echo $i; ?>" required>
                                    <span></span>
                               </div> 
                               <div class="txtb" style="width:70%;">
                                    <label for="survey_opt1_<?php echo $i; ?>">Option 1</label><br>
                                    <input type="text" name="survey_opt1_<?php echo $i; ?>" required>
                                    <span></span>
                               </div>   
                               <div class="txtb" style="width:70%;">
                                    <label for="survey_opt2_<?php echo $i; ?>">Option 2</label><br>
                                    <input type="text" name="survey_opt2_<?php echo $i; ?>" required>
                                    <span></span>
                               </div>    
                               <div class="txtb" style="width:70%;">
                                    <label for="survey_opt3_<?php echo $i; ?>">Option 3</label><br>
                                    <input type="text" name="survey_opt3_<?php echo $i; ?>" required>
                                    <span></span>
                               </div>  
                               <div class="txtb" style="width:70%;">
                                    <label for="survey_opt4_<?php echo $i; ?>">Option 4</label><br>
                                    <input type="text" name="survey_opt4_<?php echo $i; ?>" required>
                                    <span></span>
                               </div>
                               </div>
                               <?php } ?>
                              <div style="text-align: center;margin: 20px;">
                                 <center> <input type="submit" id="submit_ques" name="submit_ques" class="logbtn" value="Submit"> </center>
                              </div>
                           </form>
                       </center>
                   </div>
               </div>
            </div>
         </div>
      </div>
    <?php } else { ?>
      <div class="container" style="padding-top:50px; padding-bottom: 50px;">
         <div class="row">
            <div class="col-xs-12 col-sm-offset-3  col-sm-6">
               <div class="panel">
                   <p style="text-align:center; font-size: 25px;">Oops! No Survey Found</p>
               </div>
            </div>
         </div>
      </div>  
        <?php } ?>
   </body>
</html>
<?php 
if(isset($_POST['submit_ques'])){
    $survey_id = $_SESSION['s_id'];
    for($counts = 1; $counts <= $_SESSION['s_count']; $counts++){
        $question = $_POST['survey_questionn'.$counts];
        $question =  mysqli_real_escape_string($con_survey, $question);
        $option1 = $_POST['survey_opt1_'.$counts];
        $option1 =  mysqli_real_escape_string($con_survey, $option1);
        $option2 = $_POST['survey_opt2_'.$counts];
        $option2 =  mysqli_real_escape_string($con_survey, $option2);
        $option3 = $_POST['survey_opt3_'.$counts];
        $option3 =  mysqli_real_escape_string($con_survey, $option3);
        $option4 = $_POST['survey_opt4_'.$counts];
        $option4 =  mysqli_real_escape_string($con_survey, $option4);
        if($question != ""){
            if($option1 != ""){
                if($option2 != ""){
                    if($option3 != ""){
                        if($option4 != ""){
                            $query = "INSERT INTO survey_questions(survey_id, survey_question, opt1, opt2, opt3, opt4)VALUES('" . $survey_id . "','" . $question . "','" . $option1 . "','" . $option2 . "','" . $option3 . "','" . $option4 . "')";
                            $check=mysqli_query($con_survey, $query) or die(mysqli_error($con_survey));
                            if($check){
                                echo "<script>alert('Added Successfully')</script>";
                                echo ("<script>location.href='admin_index.php'</script>");
                            } else {
                                echo "<script>alert('Try Again')</script>";
                            }
                        } else {
                            echo "<script>alert('Please Enter Option 4 of Question $counts')</script>";
                            exit();
                        }
                    } else {
                       echo "<script>alert('Please Enter Option 3 of Question $counts')</script>";
                       exit(); 
                    }
                } else {
                   echo "<script>alert('Please Enter Option 2 of Question $counts')</script>";
                   exit(); 
                }
            } else {
                echo "<script>alert('Please Enter Option 1 of Question $counts')</script>";
                exit();
            }
        } else{
            echo "<script>alert('Please Enter Question $counts')</script>";
            exit();
        }
    }
}
?>