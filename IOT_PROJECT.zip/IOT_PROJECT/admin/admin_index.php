<?php
   require("admin_connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:../login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       if($email != "admin@fourmex.com"){
           header('Location:../home.php');
       }
        $error = null;
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="..\design\css\bootstrap.css">
      <script type="text/javascript" src="..\design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="..\design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="..\design\css\animate.min.css">
      <script type="text/javascript" src="..\design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="style_admin.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Admin | Forumex</title>
      <style>
         .panel{
         width: 100%;
         height: auto;
         border-radius: 0px;
         margin-bottom: 50px;
         }
         .panel-heading{
           text-align: center;
         }
         .panel-body{
            border: 1px solid rgb(0,0,0);
         }
         form{
         width: 50%;
         position: relative;
         }
         input{
             text-align: center;
             width: 100%;
         }
         table{
         width: 100%;
         height: 100%;
         }
         thead{
         font-weight: bold;
         text-align: center;
         }
         tr,td,th{
         padding: 10px;
         }
         tr{
           border-bottom: 1px solid black;
         }
         tr:last-child{
             border-bottom: 0px;
         }
         th,td{
              border-right: 1px solid black;
         }
        .survey_list:hover{
         background-color: #f8f8ff;
         border: 0px;
         }
         .links > a{
             color: rgb(0,0,0);
         }
          .left,.right{
                opacity: 0;
            }
            .left.animate__backInLeft,.right.animate__backInRight{
                opacity: 1;
                animation-duration: 1s;
            }
         
      </style>
   </head>
   <body>
      <?php
         require 'header_admin.php';
         ?>
      <div class="container" style="padding-top:50px;">
         <div class="row">
           <?php  
                require 'add_survey_category.php'; 
                require 'list_survey.php'; 
           ?>
         </div>
      </div>
   </body>
</html>
<script>
   $(".txtb input").on("focus", function () {
       $(this).addClass("focus");
   });
   
   $(".txtb input").on("blur", function () {
       if ($(this).val() === "")
           $(this).removeClass("focus");
   });
   $(document).ready(function () {
        $('.left').waypoint(function (direction) {
            $('.left').addClass('animate__backInLeft');
        }, {
            offset: '100%'
        });
        $('.right').waypoint(function (direction) {
            $('.right').addClass('animate__backInRight');
        }, {
            offset: '100%'
        });
    });
</script>