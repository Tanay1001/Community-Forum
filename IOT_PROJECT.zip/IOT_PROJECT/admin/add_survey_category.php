<?php
   if(isset($_POST['submit_survey'])){
       if(!empty($_POST['survey_title'])){
           $survey_title = $_POST['survey_title'];
           $survey_title = mysqli_real_escape_string($con_survey,$survey_title);
           $query = "INSERT INTO survey_main(survey_heading)VALUES('" . $survey_title . "')";
           $check=mysqli_query($con_survey, $query) or die(mysqli_error($con_survey));
           if($check){
               echo "<script>alert('Added Successfully')</script>";
               echo ("<script>location.href='admin_index.php'</script>");
           } else {
               echo "<script>alert('Try Again')</script>";
           }
       }
   }
   ?>
<div class="col-xs-12 col-sm-4" style="padding-top:10px;">
    <div class="panel left">
        <div class="panel-heading">
            <h4>Add a Survey</h4>
        </div>
        <div class="panel-body">
            <center>
                <p id="error_message" style="color:rgb(255,0,0); font-size: 12px;"><?php echo $error; ?></p>
                <form  id="my-form"  onsubmit="return doValidate_survey()" method="POST" >
                    <div class="txtb">
                        <label for="survey_title">Surevy Title</label>
                        <center><input  id="survey_title"   name="survey_title">
                        <span></span>
                        </center>
                    </div>
                    <div style="text-align: center">
                        <center> <input type="submit" id="submit_survey" name="submit_survey" class="logbtn" value="Add"> </center>
                    </div>
                </form>
            </center>
         </div>
    </div>
</div>
<script>
       function doValidate_survey(){
       var title = document.getElementById('survey_title').value;
       if (title == "") {
           document.getElementById('error_message').innerHTML = "Please Enter Survey Title*";
           return false;
       }
   }
 </script>  