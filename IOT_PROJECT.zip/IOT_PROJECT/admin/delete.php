<?php
session_start();
 require("admin_connection.php");
if(isset($_SESSION['user_email'])){
    $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       if($email != "admin@fourmex.com"){
           header('Location:../home.php');
       }
}
if(isset($_GET['id'])){
   $survey_id = $_GET['id'];
   $del = "update survey_main set survey_visibility = 'Delete' where survey_id = '$survey_id'";
   $del = mysqli_query($con_survey, $del);
   if($del){
       header('location:admin_index.php');
   } else {
       echo "<script>alert('Something Went Wrong')</script>";
       echo "<script>location.href='admin_index.php'</script>";
   }
}
