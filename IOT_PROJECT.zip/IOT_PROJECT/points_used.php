 <?php
$sel = "select * from wallet_used where user_id = '$id' order by id desc";
$sel = mysqli_query($con, $sel) or die(mysqli_error($con));
if(mysqli_num_rows($sel) == 0){ ?>
<div class="row">
      <div class="col-xs-12">
                 <div class="container" style="paddin-top:100px;">
                          <div class="row">
                              <div class="col-xs-12" style="">
                                  <center>
                                  <img src="design/image/emoj.gif" style="width: 30%; height: 50%;" alt=""/>
                                  <h1>Oops! No Points Used</h1>
                                  </center>
                              </div>
                          </div>
                      </div>
            </div>
</div>
<?php } else {
?>
<table>
    <tbody>
        <?php
        while ($result = mysqli_fetch_array($sel)){
    $order_id = $result['order_id'];
    $point = $result['point'];
    $date = $result['datetime'];
        ?>
        <tr>
            <td style="width: 80%;"><p style="font-weight: bold; color: rgb(255,0,0);">- <?php echo $point." Points"; ?></p>
                <p>For Order Id &nbsp;<?php echo strtoupper($order_id); ?></p>
            </td>
            <td><p style="font-weight: bold;"><?php echo $date; ?></p></td>
        </tr>
   <?php } ?>
<?php } ?>
    </tbody>
</table>
    