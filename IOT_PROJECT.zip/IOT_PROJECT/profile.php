<?php
session_start();
require("includes/connection.php");
if(isset($_SESSION['user_email'])){
    $email = $_SESSION['user_email'];
    $id = $_SESSION['user_id'];
}
	function GetImageExtension($imagetype){
		if(empty($imagetype)) return false;
		switch($imagetype){
			case 'image/bmp': return '.bmp';
			case 'image/gif': return '.gif';
			case 'image/jpeg': return '.jpg';
			case 'image/png': return '.png';
			default: return false;
		}
	}
if(isset($_POST['submit_profile'])){
    	if (!empty($_FILES["uploadedimage"]["name"])) {
		$file_name=$_FILES["uploadedimage"]["name"];
		$temp_name=$_FILES["uploadedimage"]["tmp_name"];
		$imgtype=$_FILES["uploadedimage"]["type"];
		$ext= GetImageExtension($imgtype);
                if($ext != false){
		$imagename=date("d-m-Y")."-".time().$ext;
		$target_path = "design/image_profile/".$imagename;
		if(move_uploaded_file($temp_name, $target_path)){
			$query="update users set profile = '$target_path' where user_id = '$id'";
			$result=mysqli_query($con, $query) or die(mysqli_error($con)); 
			if($result){
				echo "<script>self.location='account_details.php?user_id=$id';</script>";
			} else {
                            echo "<script>alert('Something Went Wrong')</script>";
                            echo "<script>self.location='account_details.php?user_id=$id';</script>";
                        }
		}
        } else {
            echo "<script>alert('Please Upload a Picture')</script>";
                            echo "<script>self.location='account_details.php?user_id=$id';</script>";
        }
	} else {
            echo "<script>alert('Please Insert Image')</script>";
            echo "<script>self.location='account_details.php?user_id=$id';</script>";
        }
}
