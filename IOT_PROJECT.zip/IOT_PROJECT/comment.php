<?php
session_start();
require("includes/connection.php");
if(isset($_SESSION['user_email'])){
    $email = $_SESSION['user_email'];
    $id = $_SESSION['user_id'];
}
if(isset($_POST['submit_question_answer_comment'])){
  $comment = $_POST['comment_form'];
  $comment = mysqli_real_escape_string($con, $comment);
  $ans_id = $_POST['aid'];
  $qid = $_POST['qid'];
  $add_comment = "insert into answer_reply(answer_id,user_id,reply) values('".$ans_id."','".$id."','".$comment."')";
  $add_comment = mysqli_query($con, $add_comment);
  if($add_comment){
      $comment_id = mysqli_insert_id($con);
      $update_ans = "select * from answer where id ='$ans_id'";
      $update_ans = mysqli_query($con, $update_ans);
      $update_ans_fetch = mysqli_fetch_array($update_ans);
      $sum = $update_ans_fetch['total_comments'] + 1;
      $ans_user_id = $update_ans_fetch['user_id'];
      $final_update = "update answer set total_comments='$sum' where id='$ans_id'";
      $final_update = mysqli_query($con, $final_update);
      if($final_update){
           include'email_comment.php'; 
           echo "<script>alert('Successfully Added Comment')</script>";
           echo ("<script>location.href='answer_view_main.php?id=$ans_id&qid=$qid#comments'</script>");
      } else {
          $del = "delete from answer_reply where id='$comment_id'";
          $del = mysqli_query($con, $del);
          echo "<script>alert('Try Again')</script>";
          echo ("<script>location.href='answer_view_main.php?id=$ans_id&qid=$qid#comments'</script>");
      }
     
  } else {
      echo "<script>alert('Try Again')</script>";
      echo ("<script>location.href='answer_view_main.php?id=$ans_id&qid=$qid#comments'</script>");
  }
}
?>