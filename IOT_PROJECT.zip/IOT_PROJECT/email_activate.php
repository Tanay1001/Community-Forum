<?php
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <fourmex.iot.c038.c036.c046.c126@gmail.com>' . "\r\n";
$to = $email;
$subject = "Activate Your Forumex Account";
$message = "<h3>Dear $name,</h3>"
        . "<h5>Click The Link To Activate Your Account"
        . "<h5><a href='localhost/IOT_PROJECT/activate.php?token=$token'>http://localhost/IOT_PROJECT/activate</a></h5>"
       ; 
ini_set("SMTP","ssl://smtp.gmail.com");
ini_set("smtp_port","587");
if(mail($to,$subject,$message,$headers)){
    $_SESSION['display'] = "True";
    $_SESSION['activate_email'] = "Check Your Email TO Activate Your Account";
    echo ("<script>location.href='login.php'</script>");
} else {
    $del = "delete from users where user_id='$user_id'";
    $del=mysqli_query($con_survey, $del) or die(mysqli_error($con_survey));
    $error = "Some error occurred. Please try again.";
}
?>