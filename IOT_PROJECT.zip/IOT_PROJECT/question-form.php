
   <div class="modal fade" id="questions-form">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Ask a Question</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                  <p id="error_message_question" style="color:rgb(255,0,0); font-size: 12px;"></p>
                  <form  onsubmit="return validate_question()" action="question-form-submit.php" style="width: 50%;" method="POST">
                     <div class="txtb">
                        <label for="question_form">Question : </label><br>
                        <input type="text" name="question_form" id="question_form" >
                        <span></span>
                     </div>
                     <div style="text-align: center">
                        <center> <input type="submit" id="question_submit" name="question_submit" class="logbtn" value="Submit Question"> </center>
                     </div>
                  </form>
               </center>
            </div>
         </div>
      </div>
   </div>
<script>
    function validate_question(){
        var question_form = document.getElementById('question_form').value;
        if(validate_email(question_form)){
            return true;
        } else{
            document.getElementById('error_message_question').innerHTML = "Please Enter Question*";
            return false;
        }
    }
</script>
    