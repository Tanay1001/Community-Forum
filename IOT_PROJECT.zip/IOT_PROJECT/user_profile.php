<?php
   if(isset($_POST['submit_name'])){
       $name_form = $_POST['name_form'];
       $name_form = mysqli_real_escape_string($con, $name_form);
       $select = "update users SET user_name = '$name_form' where user_id = '$id' ";
       $result = mysqli_query($con, $select) or die($mysqli_error($con));
       if($result){
           echo "<script>alert('Name Updated')</script>";
           echo "<script>self.location='account_details.php?user_id=$id'</script>";
       } else {
           echo "<script>alert('Try Again')</script>";
           echo "<script>self.location='account_details.php?user_id=$id'</script>";        
       }
   }
   ?>
<center>
    <div class="change_show" style="display: inline;">
    <h1 style="display:inline;"><?php echo $users_name; ?></h1>&nbsp; &nbsp;  
<?php if(isset($_SESSION['user_email']) && $_SESSION['user_email'] == $num['user_email']){ ?>
    <a class="change" data-target="#name" data-toggle="modal">Change Name</a>
       <div class="modal fade" id="name">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Change Your Name</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                  <form  method="POST">
                     <div class="txtb">
                        <label for="name_form">Enter Your New Name</label><br>
                        <center><input type="text" name="name_form" id="name_form"  required>
                           <span></span>
                        </center>
                     </div>
                     <div style="text-align: center">
                        <center> <input type="submit" name="submit_name" class="logbtn" value="Change Your Name"> </center>
                     </div>
                  </form>
               </center>
            </div>
         </div>
      </div>
       </div>
      <?php } ?>
    </div>
<input type="button" value="Share" onclick="Copy();" style="background-color: transparent; border: none;" />
<textarea id="url"  style="opacity: 0;"></textarea></center>

<script>
   function Copy() {
     var Url = document.getElementById("url");
     Url.innerHTML = window.location.href;
     console.log(Url.innerHTML);
     Url.select();
     document.execCommand("copy");
     alert("Link Copied");
   }
</script>