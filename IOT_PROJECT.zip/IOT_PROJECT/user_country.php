<br><span style="font-weight: 700;">Location: </span>
<div class="change_show"><div style="display:inline;"><?php echo $user_location; ?></div>
     <?php if(isset($_SESSION['user_email']) && $_SESSION['user_email'] == $num['user_email']){ ?>
    <a data-target="#country" data-toggle="modal" class="change">Change Country</a>
       <div class="modal fade" id="country">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Change Your Country</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                   <form class="login-form" style="width: 300px;" method="POST">
                   <div class="txtb">
                        <label for="location">Enter Your Country:</label><br>
                        <center><input type="text" name="location" id="location"  required>
                           <span></span>
                        </center>
                     </div>
                     <div style="text-align: center">
                         <center> <input type="submit" id="submit_location" name="submit_location" class="logbtn" value="Update"> </center>
                     </div>
                  </form>
               </center>
            </div>
         </div>
      </div>
   </div>
      <?php } ?> 
</div>
<?php
   if(isset($_POST['submit_location'])){
       if(!empty($_POST['location'])){
       $name_form = $_POST['location'];
       $name_form = mysqli_real_escape_string($con, $name_form);
       $select = "update users SET user_country = '$name_form' where user_id = '$id' ";
       $result = mysqli_query($con, $select) or die($mysqli_error($con));
       if($result){
           echo "<script>alert('Location Updated')</script>";
           echo "<script>self.location='account_details.php?user_id=$id'</script>";
       } else {
           echo "<script>alert('Try Again')</script>";
           echo "<script>self.location='account_details.php?user_id=$id'</script>";        
       }
   }
   }
   ?>
