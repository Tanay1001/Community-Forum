<?php
session_start();
               require("includes/connection.php");
               if(isset($_GET['token'])){
                   $token = $_GET['token'];
               }
                              $error = null;
if(isset($_POST['submit'])){
    if( !empty($_POST['c_n_password']) && !empty($_POST['n_password']) ){
        $password = $_POST['n_password'];
   	$password = mysqli_real_escape_string($con, $password);
        $npassword = $_POST['c_n_password'];
   	$npassword = mysqli_real_escape_string($con, $npassword);
        $regex_password = "/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/";
        $query = "SELECT * FROM users WHERE token='$token'";
   	$result = mysqli_query($con, $query)or die(mysqli_error($con));
        if(mysqli_num_rows($result) == 1){
            if(preg_match($regex_password, $password)){
                if(preg_match($regex_password, $npassword)){
                    $password = MD5($password);
                    $update = "update users set user_password = '$password' where token = '$token'";
                    $update = mysqli_query($con, $update)or die(mysqli_error($con));
                    if($update){
                        $query = "SELECT * FROM users WHERE token='$token'";
   	                $result = mysqli_query($con, $query)or die(mysqli_error($con));
                        $fetch = mysqli_fetch_array($result);
                        require 'email_password.php';
                        echo "<script>self.location='login.php'</script>";
                    } else {
                        $error = "Something Went Wrong";
                    }
                } else {
                    $error = "Password Should be of length 8-20 with Atleast 1 Uppercase Letter, Atleast 1 Lowercase Letter, Atleast 1 Digit, Atleast 1 Special Character";
                }
            } else {
                $error = "Password Should be of length 8-20 with Atleast 1 Uppercase Letter, Atleast 1 Lowercase Letter, Atleast 1 Digit, Atleast 1 Special Character";
            }
        } else {
            $error = "No User Found";
        }
    }
}
?>
<!DOCTYPE html>
<html>
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <script type="text/javascript" src="design/js/validation.js" ></script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <style>
          body{
              font-family: 'Arial,sans-serif';
          }
          #loads{
               background: url('design/image/Forumex Loading.gif') no-repeat center center;
               position: absolute;
               top: 0;
               left: 0;
               height: 100%;
               width: 100%;
               z-index: 9999999;
          }
          .panel{
              border-radius: 5%;
          }
          form {
         position: relative;
         width: 250px;
         }
         input{
         text-align: center;
         }
      </style>
   </head>
   <body>
        <div id="loads"></div>
       <div id="info"> 
           <?php if(isset($_GET['token'])){
               $sel = "select * from users where token = '$token' and user_status = 'Active'";
               $sel = mysqli_query($con, $sel) or die(mysqli_error($con));;
               if(mysqli_num_rows($sel) == 1){ ?>
           <center><div class="container" style="padding-top:50px;">
               <div class="row">
                   <div class="col-xs-12">
                       <h1 style="text-shadow: 5px 5px rgb(0,0,0,0.2); font-weight:bold;">Forumex</h1>
                   </div>
                   <div class="col-xs-12 col-sm-offset-3 col-sm-6">
                       <div class="panel">
                           <div class="panel-heading" style="border-bottom:1px solid rgb(0,0,0);">
                               <h3>Recover Your Account</h3>
                           </div>
                           <div class="panel-body">
                               <p id="error_message" style="color:rgb(255,0,0); font-size: 12px;">
                                <?php echo $error; ?></p>
                               <form  id="my-form"  onsubmit="return doValidates()"  method="POST" >
                              <div class="txtb">
                                 <label for="email">Enter New Password: </label>
                                 <center><input   type="password" id="n_password"   name="n_password">
                                    <span></span>
                                 </center>
                              </div>
                              <div class="txtb">
                                 <label for="password">Re-enter New Password: </label>
                                 <center>  	<input type="password" id="c_n_password" name="c_n_password" >
                                    <span ></span>
                                 </center>
                              </div>
                              <div style="text-align: center">
                                  <center> <input type="submit" id="submit" name="submit" class="logbtn" value="Login"> </center>
                              </div>
                           </form>
                           </div>
                       </div>
                   </div>
               </div>
               </div></center>
            <?php   } else { ?>
                  <div class="row">
            <div class="col-xs-12">
               <center>
                  <h2>Oops! Something Went Wrong</h2>
               </center>
            </div>
         </div>
            <?php   }
           } else { ?>
          <div class="row">
            <div class="col-xs-12">
               <center>
                  <h2>Oops! No Page Found</h2>
               </center>
            </div>
         </div>
         <?php  }?>
</div>
   </body>
</html>
<script type="text/javascript" src="design\js\form_animation.js"></script>
<script type="text/javascript" src="design\js\page_animation.js"></script>
<script>
   $(document).ready(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
  document.getElementById("loads").style.display="block";
  document.getElementById("info").style.display="none";
  setTimeout("hide()", 2000);
});
function hide() {
    document.getElementById("loads").style.display="none";
    document.getElementById("info").style.display="block";
}
function  doValidates(){
    var password = document.getElementById('n_password').value;
    var c_password = document.getElementById('c_n_password').value;
    if(c_password == "" && password == ""){
            document.getElementById("error_message").innerHTML = "All Fields are Required*";
            return false;
        } 
    if(validate_passoword(password)){
        if(validate_passoword(c_password)){
            if(validate_password_pattern(password)){
                if(validate_password_pattern(c_password)){
                    if (password == c_password){
                        return true;
                    } else {
                       document.getElementById("error_message").innerHTML = "Please Match Both the Password*";
                  return false; 
                    }
                } else {
                     document.getElementById("error_message").innerHTML = "Password Should be of length 8-20 with Atleast 1 Uppercase Letter, Atleast 1 Lowercase Letter, Atleast 1 Digit, Atleast 1 Special Character";
            return false;
                }
            } else {
                 document.getElementById("error_message").innerHTML = "Password Should be of length 8-20 with Atleast 1 Uppercase Letter, Atleast 1 Lowercase Letter, Atleast 1 Digit, Atleast 1 Special Character";
            return false;
            }
        } else {
            document.getElementById("error_message").innerHTML = "Please Re-Enter New Password*";
                  return false;
        }
    } else {
        document.getElementById("error_message").innerHTML = "Please Enter New Password*";
                  return false;
    }
}
</script> 