<!DOCTYPE html>
<html>
   <head>
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <style>
          #loads{
               background: url('design/image/Forumex Loading.gif') no-repeat center center;
               position: absolute;
               top: 0;
               left: 0;
               height: 100%;
               width: 100%;
               z-index: 9999999;
          }
      </style>
   </head>
   <body>
       <div id="info"> 
<?php 
session_start();
require("includes/connection.php");
if(isset($_SESSION['user_email'])){
    $email = $_SESSION['user_email'];
    $id = $_SESSION['user_id'];
}
if(isset($_POST['question_submit'])){ ?>
            <div id="loads"></div>
            <?php
    $question_form = $_POST['question_form'];
    $question_form = mysqli_real_escape_string($con, $question_form);
    if($question_form != ""){
        $query = "INSERT INTO question(user_id, question)VALUES('" . $id . "','" . $question_form . "')";
   	$check=mysqli_query($con, $query) or die(mysqli_error($con));
        if($check){
            $ques_id = mysqli_insert_id($con);
            echo "<script>alert('Successfully Added')</script>";
            echo "<script>self.location='answer_view.php?id=$ques_id'</script>";
        } else {
            echo "<script>alert('Try Again')</script>";
            echo "<script>self.location='home.php?answered'</script>";
        }
    }
} else {
    echo "<script>alert('Error Page Not Found')</script>";
}
?>
</div>
   </body>
</html>
<script>
   $(document).ready(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
  document.getElementById("loads").style.display="block";
  document.getElementById("info").style.display="none";
  setTimeout("hide()", 2000);
});
function hide() {
    document.getElementById("loads").style.display="none";
    document.getElementById("info").style.display="block";
}
</script> 