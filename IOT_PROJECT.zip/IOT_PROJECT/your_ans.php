<?php
$sel = "select * from answer where user_id = '$id' order by id desc";
$sel = mysqli_query($con, $sel) or die(mysqli_error($con));
if(mysqli_num_rows($sel) > 0){
$quesid = array();
while($row = mysqli_fetch_array($sel)){
    $quesid[] = $row['question_id'];
}
$count = 0;
$sel = "select * from question where id in (".implode(',',$quesid).") order by id desc";
$sel = mysqli_query($con, $sel) or die(mysqli_error($con));
?>
<div class="row" id="your_ans">
    <div class="col-xs-12 col-sm-offset-2 col-sm-8">
        <?php  while ($row = mysqli_fetch_array($sel)){ $count++; ?>
        <div class="question-card zoom">
            <div class="row" style="display: flex;width:100%; height: 100%;">
              <div class="col-xs-4 col-sm-2 side_question-card">
                  <?php echo $row['total_visitor']." Views";?><br>
                  <?php echo $row['total_answer']." Answers";?><br>
                  <a type="button" value="Share" onclick="Copy(<?php echo $count?>);" style="background-color: transparent; border: none; color: rgb(0,0,0);" >Share</a>
                  <input id="url<?php echo $count?>" style="display:none;"value="<?php echo "http://localhost/IOT_PROJECT/answer_view.php?id=".$row['id'];?>">
              </div>
             <div class="col-xs-9 col-sm-10" style="padding:10px 0px 5px 5px; border-left:1px solid rgb(0,0,0);">
                 <a href="answer_view.php?id=<?php echo $row['id']; ?>" style="color:rgb(0,0,0);"><?php  echo nl2br($row['question']); ?></a>
             </div>
            </div>
        </div>
        <?php if($count % 4 == 0){ ?>
      <div class="add-card zoom" >
         <a href="https://www.amazon.in/" target="_blank"><img src="design/image/add.gif" alt=""/></a>
      </div>
      <?php } ?>
        <?php } ?>
    </div>    
</div>
<?php } else { ?>
<div class="row">
      <div class="col-xs-12">
                 <div class="container" style="paddin-top:100px;">
                          <div class="row">
                              <div class="col-xs-12" style="">
                                  <center>
                                  <img src="design/image/emoj.gif" style="width: 50%; padding: 0px;height: 100%; margin: 0px;" alt=""/>
                                  <h1>Oops! You Have Not Answered Any Questions</h1>
                                  </center>
                              </div>
                          </div>
                      </div>
            </div>
</div>
<?php } ?>