<?php
$q_user_id =$row_qu['user_id'];
$question_user_email = "select * from users where user_id ='$q_user_id'";
$question_user_email = mysqli_query($con, $question_user_email);
$question_user_email_fetch = mysqli_fetch_array($question_user_email);
$user_email_send = $question_user_email_fetch['user_email'];
$user_name_send =  $question_user_email_fetch['user_name'];
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <fourmex.iot.c038.c036.c046.c126@gmail.com>' . "\r\n";
$to = $user_email_send;
$subject = "Answer Recieved";
$message = "<h3>Dear $user_name_send,</h3>"
        . "<h5>You have recieved an answer for you question</h5>"
        . "<a href='http://localhost/IOT_PROJECT/answer_view_main.php?id=$answer_id&qid=$ques_id'>Click Here to View the answer</a>"
       ; 
$body = "Hi, This is test email send by PHP Script";
ini_set("SMTP","ssl://smtp.gmail.com");
ini_set("smtp_port","587");
mail($to,$subject,$message,$headers);
?>

