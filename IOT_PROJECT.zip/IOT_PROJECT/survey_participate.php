<?php
   require("includes/connection.php");
   require ("admin/admin_connection.php");
     session_start();
        if (!isset($_SESSION['user_email'])) {
          header('Location:login.php');
      } else {
          $email = $_SESSION['user_email'];
          $id = $_SESSION['user_id'];
          $sel = "SELECT * FROM users WHERE user_id= '$id'";
          $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
          $row= mysqli_fetch_array($sel1);
          $users_interest = $row['user_interest'];
          $users_bio = $row['user_bio'];
          if( $users_interest == null){
              echo ("<script>location.href='user_interest_form.php'</script>");
          } elseif ($users_bio == null) {
          echo ("<script>location.href='user_bio_form.php'</script>");
      }
      if( $email == "admin@fourmex.com"){
          header('location:admin\admin_index.php');
      }
      }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Survey | Forumex</title>
      <style>
         .content{
         min-height: 300px;
         padding-top: 20px;
         padding-bottom: 20px;
         }
         .quest{
         margin: 10px;
         padding: 10px;
         width: 100%;
         border: 1px solid rgb(0,0,0);
         }
      </style>
   </head>
   <body style="background-color:rgb(255,255,255);">
      <?php if(isset($_SESSION['sid'])){
         $sidd = $_SESSION['sid'];
         $sel = "select * from survey_main where survey_id=$sidd";
         $sel = mysqli_query($con_survey, $sel) or die(mysqli_error($con_survey));
         if(mysqli_num_rows($sel) == 1 ){
         $s = mysqli_fetch_array($sel);
         $sr = $s['survey_response_received'];
         $srl = $s['survey_response'];
         $sstatus = $s['survey_status'];
         $spoint = $s['survey_point'];
         if($sr < $srl){ 
             if($sstatus == 'Active'){ ?>
      <div class="content">
         <div class="container">
            <div class="row">
               <div class="col-xs-12 zoom" style="padding:0; ">
                  <center>
                     <h2 style="text-shadow: 5px 5px rgb(0,0,0,0.2); font-weight:bold; ">Forumex Survey</h2>
                  </center>
               </div>
               <div class="col-xs-12 col-sm-offset-2 col-sm-8">
                  <?php
                     $sel = "select * from survey_questions where survey_id = $sidd";
                     $sel = mysqli_query($con_survey, $sel) or die(mysqli_error($con_survey));
                     $count = 0; ?>
                  <form  style="font-size:20px; font-family: 'Arial,sans-serif';" method="POST">
                     <?php
                        while ($result= mysqli_fetch_array($sel)){
                            $count++;
                            $survey_question = $result['survey_question'];
                            $survey_opt1 = $result['opt1'];
                            $survey_opt2 = $result['opt2'];
                            $survey_opt3 = $result['opt3'];
                            $survey_opt4 = $result['opt4'];
                        ?>
                     <div class="quest zoom">
                        <p><?php echo $count . " . " . $survey_question; ?></p>
                        <fieldset id="group<?php echo $count;?>">
                           <input type="radio" value="<?php echo $count;?>a" name="group<?php echo $count;?>" required>&nbsp;&nbsp;<?php echo $survey_opt1;?><br>
                           <input type="radio" value="<?php echo $count;?>b" name="group<?php echo $count;?>" required>&nbsp;&nbsp;<?php echo $survey_opt2;?><br>
                           <input type="radio" value="<?php echo $count;?>c" name="group<?php echo $count;?>" required>&nbsp;&nbsp;<?php echo $survey_opt3;?><br>
                           <input type="radio" value="<?php echo $count;?>d" name="group<?php echo $count;?>" required>&nbsp;&nbsp;<?php echo $survey_opt4;?><br>
                        </fieldset>
                     </div>
                     <?php } ?>
                     <div class="zoom" style="text-align: center">
                        <center> <input type="submit" id="survey_submit" name="survey_submit" class="logbtn" value="Submit Survey"> </center>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <?php } else {
         echo "<script>alert('Not Valid Survey')</script>";
         echo ("<script>location.href='survey.php'</script>");   
         }?>
      <?php } else { ?>
      <?php 
         echo "<script>alert('We are not accepting response for this survey currently')</script>";
         echo ("<script>location.href='survey.php'</script>"); ?>
      <?php  } } else {
         echo "<script>alert('No Survey Found')</script>";
         echo ("<script>location.href='survey.php'</script>"); 
         }?> 
      <?php } else { ?>
      <?php require 'includes/header.php';?>
      <div class="content">
         <div class="container">
            <div class="row">
               <div class="col-xs-12 zoom">
                  <center>
                     <h2 style="font-family: 'Arial,sans-serif'; font-size: 36px;">Something Went Wrong</h2>
                  </center>
               </div>
            </div>
         </div>
      </div>
      <?php } ?>   
   </body>
</html>
<script type="text/javascript" src="design\js\page_animation.js"></script>
<?php 
   if(isset($_POST['survey_submit'])){
       $response = '';
       for($i = 1 ; $i <= $count; $i++){
           if(!isset($_POST['group'.$i])){
               echo "<script>alert('Please Mark Question $i')</script>";
               return false;
           } else {
                $response = $response.$_POST['group'.$i].',';
           }
       }
   $sel = "select * from survey_main where survey_id=$sidd";
   $sel = mysqli_query($con_survey, $sel) or die(mysqli_error($con_survey));
   $s = mysqli_fetch_array($sel);
   $sr = $s['survey_response_received'];
   $srl = $s['survey_response'];
   $sstatus = $s['survey_status'];
   $spoint = $s['survey_point'];
   if($sr < $srl){
       if($sstatus == 'Active'){
       $query = "insert into survey_received(survey_id,user_id,response) values('".$sidd."','".$id."','".$response."')";
     $check=mysqli_query($con_survey, $query) or die(mysqli_error($con_survey));
     if($check){
         $query = "insert into wallet_received(user_id,survey_id,point) values('".$id."','".$sidd."','".$spoint."')";
         $check=mysqli_query($con, $query) or die(mysqli_error($con));
         if($check){
             $wallet_txn = mysqli_insert_id($con_survey);
             $total = (int)$sr+1;
            $query = "update survey_main SET survey_response_received = '$total' where survey_id = '$sidd' ";
             $check=mysqli_query($con_survey, $query) or die(mysqli_error($con_survey));
             if($check){
                 $sel = "select * from survey_main where survey_id='$sidd'";
   $sel = mysqli_query($con_survey, $sel) or die(mysqli_error($con_survey));
   $s = mysqli_fetch_array($sel);
   $sr = $s['survey_response_received'];
   $srl = $s['survey_response'];
   $user_sel = "select * from users where user_id = '$id'";
   $user_sel = mysqli_query($con, $user_sel);
   $user_fetch = mysqli_fetch_array($user_sel);
   $total = $spoint + $user_fetch['wallet'];
   $user_update = "update users set wallet = '$total' where user_id = '$id'";
  $user_update = mysqli_query($con, $user_update);
   if($sr == $srl){
       include 'email_wallet.php';
     $query = "update survey_main SET survey_status = 'Inactive' where survey_id = '$sidd' ";
     $check=mysqli_query($con_survey, $query) or die(mysqli_error($con_survey));
   echo "<script>alert('Survey Submitted Successfully')</script>";
      			echo ("<script>location.href='survey.php'</script>");  
   } else{
        include 'email_wallet.php';
       echo "<script>alert('Survey Submitted Successfully')</script>";
      			echo ("<script>location.href='survey.php'</script>");
   }
             } else{
             $del = "delete from survey_received where survey_id='$sidd' and user_id = '$id'";
             $del=mysqli_query($con_survey, $del) or die(mysqli_error($con_survey));
             $del = "delete from wallet_received where id='$wallet_txn'";
             $del=mysqli_query($con, $del) or die(mysqli_error($con));
             echo "<script>alert('Something Went Wrong')</script>";
             return false;
             }
         } else{
             $del = "delete from survey_received where survey_id='$sidd' and user_id = '$id'";
             $del=mysqli_query($con_survey, $del) or die(mysqli_error($con_survey));
             echo "<script>alert('Something Went Wrong')</script>";
             return false;
         }
     } else {
         echo "<script>alert('Something Went Wrong')</script>";
         return false;
     }
       } else {
          echo "<script>alert('We are not accepting response for this survey currently')</script>";
   echo ("<script>location.href='survey.php'</script>"); 
       }
   } else {
       echo "<script>alert('We are not accepting response for this survey currently')</script>";
   echo ("<script>location.href='survey.php'</script>");
   }
   }
   ?>