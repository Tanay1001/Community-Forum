<?php
   require("includes/connection.php");
   require ("admin/admin_connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       $sel = "SELECT * FROM users WHERE user_id= '$id'";
       $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
       $row= mysqli_fetch_array($sel1);
       $users_interest = $row['user_interest'];
       $users_bio = $row['user_bio'];
       if( $users_interest == null){
           echo ("<script>location.href='user_interest_form.php'</script>");
       } elseif ($users_bio == null) {
       echo ("<script>location.href='user_bio_form.php'</script>");
   }
   if( $email == "admin@fourmex.com"){
       header('location:admin\admin_index.php');
   }
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Your Stats | Forumex</title>
      <style>
             #loads{
               background: url('design/image/Forumex Loading.gif') no-repeat center center;
               position: absolute;
               top: 0;
               left: 0;
               height: 100%;
               width: 100%;
               z-index: 9999999;
          }
           .content{
         padding-top: 100px;
         padding-bottom: 20px;
         }
         .question-card{
             font-size: 14px;
              width: 100%;
              height: 100%;
              margin-top: 5px;
              /* border: 1px solid rgb(0,0,0); */
              border-radius: 5px;
              background-color: rgb(255,255,255);
              word-wrap: break-word;
          }
          .question-card:hover{
              border: 1px solid rgb(0,0,0);
               background-color: #f8f8ff;
          }
          .side_question-card{
              width: auto;
              height: 100%;
              line-height: 20px; 
              padding: 20px 5px 10px 20px; 
          }
      </style>
   </head>
   <body>
      <?php
         require 'includes/home_header.php';
          ?>
        <div id="loads"></div>
        <div class="content" id="main">
           <div class="container">
               <div class="row zoom">
                   <div class="col-xs-12" style="border-bottom:1px solid rgb(0,0,0);">
                       <?php 
                       $sel = "select total_visitor from answer where user_id = '$id'";
                       $sel = mysqli_query($con, $sel) or die(mysqli_error($con));
                       $sum_view = 0;
                       while ($sel_fetch = mysqli_fetch_array($sel)){
                           $sum_view += $sel_fetch['total_visitor'];
                       }
                       ?>
                       <h2 style="font-family: 'Arial,sans-serif'; font-size: 36px;">Views : <?php echo $sum_view;?>&nbsp;&nbsp;&nbsp;
                           </h2>
                   </div>
                   
                   <div class="col-xs-12">
                       <?php 
   $sel = "select * from answer where user_id = '$id' order by id desc";
   $sel = mysqli_query($con, $sel) or die(mysqli_error($con));
   if(mysqli_num_rows($sel) > 0){
   $count = 0;
   ?>
                       <div class="col-xs-12">
                       <h2 style="font-family: 'Arial,sans-serif'; font-size: 25px;">Your Answered Questions</h2>
                   </div>
<div class="row" id="answered">
   <div class="col-xs-offset-0 col-xs-12 col-sm-offset-2 col-sm-8">
      <?php        while ($row = mysqli_fetch_array($sel)){ 
           $question_id = $row['question_id'];
           $sel_question = "select * from question where id = '$question_id'";
           $sel_question = mysqli_query($con, $sel_question) or die(mysqli_error($con));
           $sel_fetch_question = mysqli_fetch_array($sel_question);
          $count++;?>
      <div class="question-card zoom">
          <div class="row" style="display: flex;width:100%; height: 100%;">
              <div class="col-xs-4 col-sm-2 side_question-card" >
               <?php echo $row['total_visitor']." Views";?> <br>
<a type="button" value="Share" onclick="Copy(<?php echo $count?>);" style="background-color: transparent; border: none; color: rgb(0,0,0);" >Share</a>         
<input id="url<?php echo $count?>" style="display:none;"value="<?php echo "http://localhost/IOT_PROJECT/answer_view_main.php?id=".$row['id']."&qid=".$question_id;?>">
                </div>
            <div class="col-xs-9 col-sm-10" style="padding:10px 0px 5px 5px; border-left:1px solid rgb(0,0,0); font-size: 16px;">
               <a href="answer_view_main.php?id=<?php echo $row['id']."&qid=".$question_id; ?>" style="color:rgb(0,0,0);"><?php  echo nl2br($sel_fetch_question['question']); ?></a>
            </div>
         </div>
      </div>
   <?php } } else { ?>
       <div class="row">
      <div class="col-xs-12">
                 <div class="container" style="paddin-top:100px;">
                          <div class="row">
                              <div class="col-xs-12" style="">
                                  <center>
                                  <img src="design/image/emoj.gif" style="width: 30%; height: 50%;" alt=""/>
                                  <h1>Oops! You Have Not Any Questions</h1>
                                  </center>
                              </div>
                          </div>
                      </div>
            </div>
</div>
  <?php } ?>
   </div>
</div>
                   </div>
               </div>
           </div>
       </div>
   </body>
</html>
<script type="text/javascript" src="design\js\page_animation.js"></script>
<script>
     $(document).ready(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
  document.getElementById("loads").style.display="block";
  document.getElementById("main").style.display="none";
  setTimeout("hide()", 2000);
});
function hide() {
    document.getElementById("loads").style.display="none";
    document.getElementById("main").style.display="block";
}
   function Copy(count) {
     /* Get the text field */
   var copyText = document.getElementById('url'+count);
   
   /* Select the text field */
   console.log(copyText.value);
   copyText.select();
   copyText.setSelectionRange(0, 99999); /* For mobile devices */
   
   /* Copy the text inside the text field */
   navigator.clipboard.writeText(copyText.value);
   
   /* Alert the copied text */
   alert("Link Copied");
   }
</script>