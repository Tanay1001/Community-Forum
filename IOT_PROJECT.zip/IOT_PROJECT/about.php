<?php
   require("includes/connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       
   } else {
       $email = $_SESSION['user_email'];
       $uid = $_SESSION['user_id'];
   }
   ?>
<!DOCTYPE html>
<html>
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title> About Us  | FORUMEX</title>
      <style>
          .about_panel{
              background-color: #f2f9ff;
          }
          .about_panel:hover{
            background-color: rgba(108,187,247,0.4);  
          }
         .products {
         border-bottom: 1px solid rgba(0,0,0,0.2); 
         line-height: 0.1em;
         margin: 10px 0 20px; 
         opacity: 0;
         } 
         .products > span { 
         background-color: rgb(255,255,255);
         padding:0 10px; 
         }
         .cards{
         background-color: #f2f9ff;
         color: #3c4146;
         padding-top: 40px; padding-bottom: 20px;
         margin-right: 20px; margin-left: 20px;
         border-radius: 10px; 
         }
         .cards:hover{
         background-color: rgba(108,187,247,0.4);
         }
         .about_btn{
         background-color: #0095ff;
         font-size: 18px; 
         color: rgb(255,255,255);
         padding: 10px 30px 10px 30px;
         border-radius: 10px;
         }
         .about_btn:hover{
         color: rgb(255,255,255);
         }
         .core{
         height: 50px; width: auto;
         }
         @media(min-width:320px){
         .about_img{
         width: 300px; height: auto;
         }
         .borderss{
         text-align: center;
         border-bottom: 1px solid rgba(0,0,0,0.2);
         }
         .keys{
         margin-right: 10px; margin-left: 10px;
         }
         .last{
         margin-top: 20px;
         }
         }
         @media(min-width:760px){
         .keys{
         margin-right: auto; margin-left: auto;
         }
         .about_img{
         width: 500px; height: auto;
         } 
         .cards{
         height: 300px;
         }
         .text{
         margin-top: 20%; 
         }
         .last{margin-top: auto;}
         .second{
         margin-top: 50px;
         }
         }
         .about_panel{
         box-shadow: 10px 10px 50px 10px rgba(0,0,0,0.2);
         text-align: center;
         padding: 20px;
         width: auto;
         }
         @media(min-width:800px){
         .borderss{
         border-bottom: 0px;
         border-right: 1px solid rgba(0,0,0,0.2);
         }  
         }
      </style>
   </head>
   <body style="background-color:rgb(255,255,255);">
      <?php require 'includes/home_header.php'; ?>
      <div class="container" style="margin-top: 100px;">
         <div class="row">
            <div class="left col-xs-10 col-sm-3 col-md-6">
               <img class="about_img" src="design/image/bg-header-mobile.png" alt=""/>
            </div>
            <div class="right col-xs-10 col-sm-offset-4 col-sm-5 col-md-offset-0 col-md-6">
               <div class="row text">
                  <div class="col-xs-12" style="color:#848d95; font-weight:bold; font-size: 20px; ">Who We Are</div>
                  <div class="col-xs-12">
                     <h1>Empowering the World to Help People through Collective Knowledge</h1>
                  </div>
                  <div class="col-xs-12" style="color:#535a60; font-size:15px; padding-top:5px;">Our public platform <strong>serves 100 million people every month</strong>, 
                     making it one of the 50 most popular websites in the world.
                  </div>
                  <div class="col-xs-12" style="coloe:#535a60; font-size: 15px; padding-top: 5px;">Founded in 2008, Fourmex’s public
                     platform is used by nearly everyone who wants to learn, share their knowledge, collaborate, and build their careers.
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="container keys" style="margin-top:40px;">
         <div class="zoom panel about_panel" style=" margin-bottom: 30px;">
            <div class="container">
               <div class="row" style="margin-right:10px; margin-left:5px">
                  <div class="col-xs-offset-1 col-xs-10 col-sm-offset-0 col-sm-3 borderss">
                     <strong style="font-size:18px;">100+ million</strong><br>
                     <p>Monthly visitors to our <br>network</p>
                  </div>
                  <div class="col-xs-offset-1 col-xs-10 col-sm-offset-0 col-sm-3 borderss">
                     <strong style="font-size:18px;">21+ million</strong><br>
                     <p>Question Asked to-<br>Date</p>
                  </div>
                  <div class="col-xs-offset-1 col-xs-10 col-sm-offset-0 col-sm-3 borderss">
                     <strong style="font-size:18px;">13.6 Seconds</strong><br>
                     <p>Average Time between<br>New Questions</p>
                  </div>
                  <div class="col-xs-offset-1 col-xs-10 col-sm-offset-0 col-sm-3">
                     <strong style="font-size:18px;">50.6+ Billion</strong><br>
                     <p>Times a Person got <br>Help</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="container" style="margin-top:60px; margin-bottom: 10px;">
         <center>
            <h1 class="products"><span><strong>Our Products</strong></span></h1>
         </center>
         <div class="row prod_content" style="margin-top: 50px;">
            <div class="col-xs-12">
               <div  class="card cards">
                  <div class="card-body">
                     <center>
                        <h2 style="font-weight:600;">Our Public Platform</h2>
                        <p style="font-size: 18px; margin-top: 20px;">Where people go to gain and share knowledge.</p>
                        <button class="btn about_btn" style=" ">Participate</button>
                     </center>
                  </div>
               </div>
            </div>
         </div>
         <div class="row" style="margin-top: 20px;">
            <div class="prod_content1 col-xs-12 col-sm-6">
               <div  class="card cards">
                  <div class="card-body">
                     <center>
                        <h2 style="font-weight:600;">Collectives</h2>
                        <p style="font-size: 18px; margin-top: 20px;">Connecting communities with the <br>specific topics they want</p>
                        <button class="btn about_btn" style=" ">Participate</button>
                     </center>
                  </div>
               </div>
            </div>
            <div class="prod_content2 col-xs-12 col-sm-6">
               <div  class="card cards last">
                  <div class="card-body">
                     <center>
                        <h2 style="font-weight:600;">Earning</h2>
                        <p style="font-size: 18px; margin-top: 20px;">People can earn money by answering questions and participating in paid surveys.</p>
                        <button class="btn about_btn" style=" ">Participate</button>
                     </center>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="container" style="margin-top: 50px; margin-bottom: 10px; ">
         <center>
            <h2 class="products"><span><strong>Our Core Values</strong></span></h2>
         </center>
         <div class="core_content row" style="margin-top:50px; color: black;">
            <div class="col-xs-12 col-sm-4">
               <img class="core" src="design/image/1.png" alt=""/><br>
               <strong  style="font-size: 23px;">Adopt a customer-first mindset</strong>
               <p style="font-size:18px; margin-top: 10px;">
                  Authentically serve our customers by empowering, 
                  listening and collaborating with our fellow Fourmexrs.
               </p>
            </div>
            <div class="col-xs-12 col-sm-4">
               <img class="core" src="design/image/2.png" alt=""/><br>
               <strong  style="font-size: 23px;">Be flexible and inclusive</strong>
               <p style="font-size:18px; margin-top: 10px;">
                  We do our best work when a diverse group of people collaborate in 
                  an environment of respect and trust. Create space for different voices
                  to be heard, and allow flexibility in how people work.
               </p>
            </div>
            <div class="col-xs-12 col-sm-4">
               <img class="core" src="design/image/3.png" alt=""/><br>
               <strong  style="font-size: 23px;">Be transparent</strong>
               <p style="font-size:18px; margin-top: 10px;">
                  Communicate openly and honestly, both inside and outside the company.
                  Encourage transparency from others by being empathetic, reliable,
                  and acting with integrity.
               </p>
            </div>
         </div>
         <div class="core_content row second" >
            <div class="col-xs-12 col-sm-4">
               <img class="core" src="design/image/4.png" alt=""/><br>
               <strong  style="font-size: 23px;">Empower people to deliver outstanding results</strong>
               <p style="font-size:18px; margin-top: 10px;">
                  Give people space to get their job done, support them when they need it,
                  and practice blameless accountability.
               </p>
            </div>
            <div class="col-xs-12 col-sm-4">
               <img class="core" src="design/image/5.png" alt=""/><br>
               <strong  style="font-size: 23px;">Keep community at our center</strong>
               <p style="font-size:18px; margin-top: 10px;">
                  Community is at the heart of everything we do. Nurture healthy 
                  communities where everyone is encouraged to learn and give back.
               </p>
            </div>
            <div class="col-xs-12 col-sm-4">
               <img class="core" src="design/image/6.png" alt=""/><br>
               <strong  style="font-size: 23px;">Learn, share, grow</strong>
               <p style="font-size:18px; margin-top: 10px;">
                  Adopt a Growth Mindset. Be curious and eager to learn. Aim for ethical, 
                  sustainable, long-term growth, both personally and in the company.
               </p>
            </div>
         </div>
      </div>
      <?php
         include 'includes/footer.php';
         ?>
   </body>
</html>
<script type="text/javascript" src="design\js\page_animation.js"></script>