<!DOCTYPE html>
<html>
   <head>
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <style>
          #loads{
               background: url('design/image/Forumex Loading.gif') no-repeat center center;
               position: absolute;
               top: 0;
               left: 0;
               height: 100%;
               width: 100%;
               z-index: 9999999;
          }
      </style>
   </head>
   <body>
        <div id="loads"></div>
       <div id="info"> 
<?php 
session_start();
require("includes/connection.php");
if(isset($_SESSION['user_email'])){
    $email = $_SESSION['user_email'];
    $id = $_SESSION['user_id'];
}
if(isset($_POST['password_submit'])){ 
    $emails = $_POST['password_email'];
    $emails = mysqli_real_escape_string($con, $emails);
    if($emails!= ""){
        $query = "select * from users where user_email='$emails' and user_status='Active'";
   	$check=mysqli_query($con, $query) or die(mysqli_error($con));
        if( mysqli_num_rows($check) == 1){
            $fetch = mysqli_fetch_array($check);
            require 'email_forgot.php';
        } else {
            echo "<script>alert('Try Again')</script>";
            echo "<script>self.location='home.php?answered'</script>";
        }
    }
} else {
    echo "<script>alert('Error Page Not Found')</script>";
}
?>
</div>
   </body>
</html>
<script>
   $(document).ready(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
  document.getElementById("loads").style.display="block";
  document.getElementById("info").style.display="none";
  setTimeout("hide()", 2000);
});
function hide() {
    document.getElementById("loads").style.display="none";
    document.getElementById("info").style.display="block";
}
</script> 