-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Oct 22, 2021 at 05:13 PM
-- Server version: 8.0.18
-- PHP Version: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fourmex`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
CREATE TABLE IF NOT EXISTS `answer` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `question_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `answer` varchar(10000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `total_visitor` int(100) NOT NULL DEFAULT '0',
  `total_comments` int(100) NOT NULL DEFAULT '0',
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(255) NOT NULL DEFAULT 'None',
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `answer_reply`
--

DROP TABLE IF EXISTS `answer_reply`;
CREATE TABLE IF NOT EXISTS `answer_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `answer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reply` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `answer_id` (`answer_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `answer_view`
--

DROP TABLE IF EXISTS `answer_view`;
CREATE TABLE IF NOT EXISTS `answer_view` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `answer_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `user_ip` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `answer_id` (`answer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `prod_id` int(100) NOT NULL,
  `qty` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `prod_id` (`prod_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

DROP TABLE IF EXISTS `order_list`;
CREATE TABLE IF NOT EXISTS `order_list` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(100) NOT NULL,
  `prod_id` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_user`
--

DROP TABLE IF EXISTS `order_user`;
CREATE TABLE IF NOT EXISTS `order_user` (
  `id` varchar(100) NOT NULL,
  `order_value` int(100) NOT NULL,
  `order_list_id` int(100) NOT NULL DEFAULT '0',
  `user_id` int(100) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gift_card_id` varchar(100) NOT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `gift_card_id` (`gift_card_id`),
  KEY `order_list_id` (`order_list_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `order_user`
--

INSERT INTO `order_user` (`id`, `order_value`, `order_list_id`, `user_id`, `datetime`, `gift_card_id`) VALUES
('988efa9e', 1000, 1, 21, '2021-10-22 22:24:08', 'a52f1ca8ac');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(100) NOT NULL,
  `prod_price` int(100) NOT NULL,
  `prod_money` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `prod_name`, `prod_price`, `prod_money`) VALUES
(1, '250 Rupees Gift Card', 1000, 250),
(2, '500 Rupees Gift Card', 2000, 500),
(3, '1000 Rupees Gift Card', 4000, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user_id` int(100) NOT NULL,
  `question` varchar(1000) NOT NULL,
  `total_answer` int(100) NOT NULL DEFAULT '0',
  `total_visitor` int(100) NOT NULL DEFAULT '0',
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `question_view`
--

DROP TABLE IF EXISTS `question_view`;
CREATE TABLE IF NOT EXISTS `question_view` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `ques_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL DEFAULT '0',
  `user_ip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ques_id` (`ques_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(100) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(250) NOT NULL,
  `user_password` varchar(250) NOT NULL,
  `user_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_country` varchar(255) NOT NULL,
  `user_bio` varchar(1000) NOT NULL,
  `user_interest` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `views` int(100) NOT NULL DEFAULT '0',
  `wallet` int(255) NOT NULL DEFAULT '0',
  `user_signup_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `token` varchar(255) NOT NULL,
  `user_status` enum('Active','Inactive') NOT NULL DEFAULT 'Inactive',
  `profile` varchar(255) NOT NULL DEFAULT 'None',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_email`, `user_password`, `user_name`, `user_country`, `user_bio`, `user_interest`, `views`, `wallet`, `user_signup_time`, `token`, `user_status`, `profile`) VALUES
(1, 'admin@fourmex.com', 'adb96d424a0f4ec4ce2d7fced13579df', 'Forumex', 'India', 'Empowering the World to Help People through Collective Knowledge\r\nOur public platform serves 100 million people every month, making it one of the 50 most popular websites in the world.Founded in 2008, Fourmex’s public platform is used by nearly everyone who wants to learn, share their knowledge, collaborate, and build their careers.', 'Technology,Studies,Sports,Finance,Music,Dance,Business,', 0, 0, '2021-10-19 17:06:34', 'fdc01e3c9a3c9d365aa1d05f89811a', 'Active', 'None'),
(3, 'gaurav.200399@gmail.com', 'adb96d424a0f4ec4ce2d7fced13579df', 'Gaurav Jha', 'India', 'Empowering the World to Help People through Collective Knowledge\r\nOur public platform serves 100 million people every month, making it one of the 50 most popular websites in the world.Founded in 2008, Fourmex’s public platform is used by nearly everyone who wants to learn, share their knowledge, collaborate, and build their careers.', 'Technology,Studies,Sports,Music,Dance,', 0, 0, '2021-10-19 19:22:34', '34e6eb54682ee3ed4b8acf993401fe', 'Active', 'design/image_profile/22-10-2021-1634897071.jpg'),
(4, 'gaurav@gmail.com', 'adb96d424a0f4ec4ce2d7fced13579df', 'Gaurav', 'India', 'Hello Jj', 'Technology,Studies,Sports,', 0, 0, '2021-10-21 02:23:00', 'a11b01301c3cfdbe040c29e697b420', 'Active', 'None'),
(5, 'parthjain748@gmail.com', 'adb96d424a0f4ec4ce2d7fced13579df', 'Parth ', 'India', 'Empowering the World to Help People through Collective Knowledge\r\nOur public platform serves 100 million people every month, making it one of the 50 most popular websites in the world.Founded in 2008, Fourmex’s public platform is used by nearly everyone who wants to learn, share their knowledge, collaborate, and build their careers.', 'Technology,Studies,Sports,', 0, 0, '2021-10-21 15:22:32', '2e00196462b1cadb9199dbef8ae43b', 'Active', 'design/image_profile/21-10-2021-1634810419.jpg'),
(21, 'johncena@gmail.com', 'adb96d424a0f4ec4ce2d7fced13579df', 'Johncena', 'India', 'My Name is Forumex', 'Technology,Studies,Sports,', 0, 0, '2021-10-22 22:13:09', '4ea6e43c2425e382251054a3969478', 'Active', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `wallet_received`
--

DROP TABLE IF EXISTS `wallet_received`;
CREATE TABLE IF NOT EXISTS `wallet_received` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user_id` int(100) NOT NULL,
  `survey_id` int(100) NOT NULL DEFAULT '0',
  `view_id` int(100) NOT NULL DEFAULT '0',
  `point` int(100) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `survey_id` (`survey_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wallet_used`
--

DROP TABLE IF EXISTS `wallet_used`;
CREATE TABLE IF NOT EXISTS `wallet_used` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user_id` int(100) NOT NULL,
  `order_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `point` int(100) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `question`
--
ALTER TABLE `question` ADD FULLTEXT KEY `question` (`question`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer`
--
ALTER TABLE `answer`
  ADD CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `answer_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `answer_reply`
--
ALTER TABLE `answer_reply`
  ADD CONSTRAINT `answer_reply_ibfk_1` FOREIGN KEY (`answer_id`) REFERENCES `answer` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `answer_reply_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `answer_view`
--
ALTER TABLE `answer_view`
  ADD CONSTRAINT `answer_view_ibfk_1` FOREIGN KEY (`answer_id`) REFERENCES `answer` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `cart_ibfk_3` FOREIGN KEY (`prod_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `order_user`
--
ALTER TABLE `order_user`
  ADD CONSTRAINT `order_user_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `question_view`
--
ALTER TABLE `question_view`
  ADD CONSTRAINT `question_view_ibfk_1` FOREIGN KEY (`ques_id`) REFERENCES `question` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `wallet_used`
--
ALTER TABLE `wallet_used`
  ADD CONSTRAINT `wallet_used_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
