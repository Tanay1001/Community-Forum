-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Oct 22, 2021 at 05:13 PM
-- Server version: 8.0.18
-- PHP Version: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin_fourmex`
--

-- --------------------------------------------------------

--
-- Table structure for table `survey_main`
--

DROP TABLE IF EXISTS `survey_main`;
CREATE TABLE IF NOT EXISTS `survey_main` (
  `survey_id` int(11) NOT NULL AUTO_INCREMENT,
  `survey_heading` varchar(255) NOT NULL,
  `survey_response` int(255) NOT NULL DEFAULT '0',
  `survey_status` enum('Inactive','Active') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'Inactive',
  `survey_point` int(30) NOT NULL DEFAULT '0',
  `total_question` int(100) NOT NULL DEFAULT '0',
  `survey_response_received` int(50) NOT NULL DEFAULT '0',
  `survey_visibility` enum('View','Delete') NOT NULL DEFAULT 'View',
  PRIMARY KEY (`survey_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `survey_main`
--

INSERT INTO `survey_main` (`survey_id`, `survey_heading`, `survey_response`, `survey_status`, `survey_point`, `total_question`, `survey_response_received`, `survey_visibility`) VALUES
(1, 'Survey Questionaire', 100, 'Active', 2000, 4, 1, 'View'),
(2, 'Customer Satisfaction Surveys', 0, 'Inactive', 0, 0, 0, 'View'),
(3, 'General Customer Experience Gauging', 100, 'Inactive', 1000, 4, 0, 'View'),
(4, 'Got a minute?', 0, 'Inactive', 0, 0, 0, 'View');

-- --------------------------------------------------------

--
-- Table structure for table `survey_questions`
--

DROP TABLE IF EXISTS `survey_questions`;
CREATE TABLE IF NOT EXISTS `survey_questions` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `survey_id` int(255) NOT NULL,
  `survey_question` varchar(255) NOT NULL,
  `opt1` varchar(1000) NOT NULL,
  `opt2` varchar(1000) NOT NULL,
  `opt3` varchar(1000) NOT NULL,
  `opt4` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_id` (`survey_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `survey_questions`
--

INSERT INTO `survey_questions` (`id`, `survey_id`, `survey_question`, `opt1`, `opt2`, `opt3`, `opt4`) VALUES
(1, 1, ' If you have not visited our forum, please could you explain the reasons why (select as many as required)', 'Too shy', 'Not relevant ', ' Didn\'t know it exisited', 'Prefer to use Social Media'),
(2, 1, 'How helpful did you find our forum?', 'Very Helpful', 'Fairly Helpful	', 'Unhelpful', 'Very Unhelpful'),
(3, 1, 'Were the answers informative?(with 4 being the highest)', '1', '2', '3', '4'),
(4, 1, 'How likely are you to recommend our Forum website to a friend?', 'Most likely', 'Probably', ' If he/she has a particular question', 'Not likely');

-- --------------------------------------------------------

--
-- Table structure for table `survey_received`
--

DROP TABLE IF EXISTS `survey_received`;
CREATE TABLE IF NOT EXISTS `survey_received` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `survey_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `response` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_received_ibfk_1` (`user_id`),
  KEY `survey_id` (`survey_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `survey_questions`
--
ALTER TABLE `survey_questions`
  ADD CONSTRAINT `survey_questions_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `survey_main` (`survey_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `survey_received`
--
ALTER TABLE `survey_received`
  ADD CONSTRAINT `survey_received_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `fourmex`.`users` (`user_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `survey_received_ibfk_2` FOREIGN KEY (`survey_id`) REFERENCES `survey_main` (`survey_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
