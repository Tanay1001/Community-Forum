<?php
   session_start();
   require("includes/connection.php");
   if (isset($_SESSION['user_email'])) {
       header('location:  home.php?answered');
   }
   ?>
<?php
   $error = null;
   if(isset($_POST['submit'])){
   $email = $_POST['email'];
   $email = mysqli_real_escape_string($con, $email);
   $password = $_POST['password'];
   $password = mysqli_real_escape_string($con, $password);
   $password = MD5($password);
   // Query checks if the email and password are present in the database.
   $query = "SELECT user_id, user_email FROM users WHERE user_email='" . $email . "' AND user_password='" . $password . "' AND user_status='Active'";
   $result = mysqli_query($con, $query)or die(mysqli_error($con));
   $num = mysqli_num_rows($result);
   // If the email and password are not present in the database, the mysqli_num_rows returns 0, it is assigned to $num.
   if ($num == 0) { 
   	$error = "Enter Valid Email and Password Combinations*";
   } else { 
     $row = mysqli_fetch_array($result);
     $_SESSION['user_email'] = $row['user_email'];
     $_SESSION['user_id'] = $row['user_id'];
     if($email == "admin@fourmex.com"){
         header('location:admin\admin_index.php');
     } else {
           header('location:home.php?answered');
     }
   }
    }
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <script type="text/javascript" src="design\js\validation.js"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title> Login | FORUMEX</title>
      <style>
         .content{
         min-height: 300px;
         font-family: 'Arial,sans-serif';
         padding-top: 100px;
         padding-bottom: 20px;
         }
         .panel{
         box-shadow: 0 15px 15px 0 rgba(0, 0, 0, 0.2);
         }
         form {
         position: relative;
         width: 200px;
         }
         input{
         text-align: center;
         }
      </style>
   </head>
   <body>
      <?php require 'includes/home_header.php'; ?>
      <div class="content">
         <div class="container">
            <div class="row">
               <div class="col-xs-offset-1 col-xs-10 col-sm-offset-4 col-sm-4 zoom" style="padding:0; ">
                  <center>
                     <h2 style="text-shadow: 5px 5px rgb(0,0,0,0.2); font-weight:bold;">Forumex</h2>
                  </center>
                  <div class="panel" >
                     <div class="panel-heading" style="text-align: center; border-bottom: 1px solid #EBEBEB;">
                        <h4>Login</h4>
                     </div>
                     <div class="panel-body">
                        <center>
                            <p id="error_message" style="color:rgb(255,0,0); font-size: 12px;">
                                <?php 
                                    echo $error; ?></p>
                            <p style="color:rgb(255,0,0); font-size: 12px;">
                                <?php  if(isset($_SESSION['activate_email'])){
                                    echo $_SESSION['activate_email'];
                                    $_SESSION['activate_email'] = null;
                                    }?></p>
                           <form  id="my-form"  onsubmit="return doValidates()"  method="POST" >
                              <div class="txtb">
                                 <label for="email">Email:</label>
                                 <center><input   id="email"   name="email">
                                    <span></span>
                                 </center>
                              </div>
                              <div class="txtb">
                                 <label for="password">Password:</label>
                                 <center>  	<input type="password" id="password" name="password" >
                                    <span ></span>
                                 </center>
                              </div>
                              <div style="text-align: center">
                                  <center> <input type="submit" id="submit" name="submit" class="logbtn" value="Login"> </center>
                              </div>
                           </form>
                           <br>
                           <div><a data-target="#forgot-password" data-toggle="modal" style="color:rgb(0,0,0);">Forgot Password?</a></div><br>
                           <a href="signup.php" style="color: rgb(0,0,0);">
                            Don't have a Account,SignUp Here
                           </a>
                        </center>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
       <?php require 'forgot-password.php';?>
   </body>
</html>
<script type="text/javascript" src="design\js\form_animation.js"></script>
<script type="text/javascript" src="design\js\page_animation.js"></script>
<script>
   function doValidates(){
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;
        if(email == "" && password == ""){
            document.getElementById("error_message").innerHTML = "All Fields are Required*";
            return false;
        } 
        if(validate_email(email)){
           if(validate_email_pattern(email)){
              if(validate_passoword(password)){
                if(validate_password_pattern(password)){
                    return true;
                } else{
                    document.getElementById("error_message").innerHTML = "Password Should be of length 8-20 with Atleast 1 Uppercase Letter, Atleast 1 Lowercase Letter, Atleast 1 Digit, Atleast 1 Special Character";
            return false;
                }
              } else{
                  document.getElementById("error_message").innerHTML = "Please Enter Password*";
                  return false;
              }
           } else{
               document.getElementById("error_message").innerHTML = "Enter Valid Email*";
               return false;
           }    
         } else{
             document.getElementById("error_message").innerHTML = "Enter Email*";
             return false;
         }
    }
</script>