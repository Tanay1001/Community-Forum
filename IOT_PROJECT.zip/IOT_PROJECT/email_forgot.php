<?php
$user_email_send = $fetch['user_email'];
$user_name_send =  $fetch['user_name'];
$user_token = $fetch['token'];
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <fourmex.iot.c038.c036.c046.c126@gmail.com>' . "\r\n";
$to = $user_email_send;
$subject = "Forgot Password";
$message = "<h3>Dear $user_name_send,</h3>"
        . "<h5>Please Click Forgot Passowrd to Recover your Account</h5>"
        . "<a href='http://localhost/IOT_PROJECT/forgot_password.php?token=$user_token'>Forgot Password</a>"
       ; 
ini_set("SMTP","ssl://smtp.gmail.com");
ini_set("smtp_port","587");
if(mail($to,$subject,$message,$headers)){
    echo "<script>alert('Check Your Email')</script>";
    echo "<script>self.location='login.php'</script>";
} else {
    echo "<script>alert('Something Went Wrong')</script>";
    echo "<script>self.location='login.php'</script>";
}
?>

