function validate_email(email){
    if (email == "") {
            return false;
        } else {
            return true;
        }
}
function validate_email_pattern(email){
     var email_pattern = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/;
     if (!email_pattern.test(email)){
            return false;
        } else{
            return true;
        }
}

function validate_passoword(password){
    if (password == ""){
            return false;
        } else{
            return true;
        }
}

function validate_password_pattern(password){
    var password_pattern =  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
    if(!password_pattern.test(password)){
        return false;
    } else{
        return true;
    }
}

function validate_name(name){
    if(name == ""){
        return false;
    } else{
        return true;
    }
}

function validate_answers(answers){
     var count = 0;
     var split = answers.split(' ');
     for (var i = 0; i < split.length; i++) {
                if (split[i] !== "") {
                    count += 1;
                }
            }
     return count;
}

