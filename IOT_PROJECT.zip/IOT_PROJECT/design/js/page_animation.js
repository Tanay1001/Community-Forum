    $(document).ready(function () {
        $('.zoom').waypoint(function (direction) {
            $('.zoom').addClass('animate__zoomIn');
        }, {
            offset: '100%'
        });
        $('.left').waypoint(function (direction) {
            $('.left').addClass('animate__backInLeft');
        }, {
            offset: '100%'
        });
        $('.right').waypoint(function (direction) {
            $('.right').addClass('animate__backInRight');
        }, {
            offset: '100%'
        });
                $('.products').waypoint(function (direction) {
            $('.products').addClass('animate__pulse');
        }, {
            offset: '50%'
        }); 
        $('.prod_content').waypoint(function (direction) {
            $('.prod_content').addClass('animate__zoomIn');
        }, {
            offset: '50%'
        });
        $('.prod_content1').waypoint(function (direction) {
            $('.prod_content1').addClass('animate__zoomIn');
        }, {
            offset: '50%'
        });
        $('.prod_content2').waypoint(function (direction) {
            $('.prod_content2').addClass('animate__zoomIn');
        }, {
            offset: '50%'
        });
        $('.core_content').waypoint(function (direction) {
            $('.core_content').addClass('animate__zoomIn');
        }, {
            offset: '50%'
        });
    });