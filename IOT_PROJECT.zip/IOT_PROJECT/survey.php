<?php
   require("includes/connection.php");
   require ("admin/admin_connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       $sel = "SELECT * FROM users WHERE user_id= '$id'";
       $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
       $row= mysqli_fetch_array($sel1);
       $users_interest = $row['user_interest'];
       $users_bio = $row['user_bio'];
       if( $users_interest == null){
           echo ("<script>location.href='user_interest_form.php'</script>");
       } elseif ($users_bio == null) {
       echo ("<script>location.href='user_bio_form.php'</script>");
   }
   if( $email == "admin@fourmex.com"){
       header('location:admin\admin_index.php');
   }
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Survey | Forumex</title>
      <style>
              #loads{
               background: url('design/image/Forumex Loading.gif') no-repeat center center;
               position: absolute;
               top: 0;
               left: 0;
               height: 100%;
               width: 100%;
               z-index: 9999999;
          }
         table{
         width: 100%;
         height: 100%;
         }
         thead{
         font-weight: bold;
         border-bottom: 1px solid black;
         }
         tr,td,th{
         font-family: 'Arial,sans-serif';
         font-size: 16px;
         padding: 10px;
         }
         th{
         text-align: center;
         font-size: 20px;
         }
         tr{
         border-bottom: 1px solid black;
         }
         tr:last-child{
         border-bottom: 0px;
         }
         th,td{
         border-right: 1px solid black;
         }
         .survey_list:hover{
         background-color: #f8f8ff;
         border: 0px;
         }
         @media(min-width:300px){
             #title,.titles{
                 width: 1000px;
             }
         }
         @media(min-width:850px){
       
         }
         @media(min-width:990px){
       
         }
      </style>
   </head>
   <body style="background-color:rgb(255,255,255);">
      <?php
         require 'includes/home_header.php';
         ?>
       <div id="loads"></div>
       <div class="container" id="main" style="padding-top: 75px;;">
         <div class="row zoom">
            <?php 
               $survey_id_temp = array();
                  $select = "SELECT * FROM survey_main WHERE survey_status = 'Active' ORDER BY `survey_id` ASC";
                  $select = mysqli_query($con_survey, $select) or die(mysqli_error($con_survey));
                  if(mysqli_num_rows($select) == 0){ ?>
            <div class="col-xs-12">
                 <div class="container" style="paddin-top:100px;">
                          <div class="row">
                              <div class="col-xs-12" style="">
                                  <center>
                                  <img src="design/image/emoj.gif" style="width: 50%; padding: 0px;height: 100%; margin: 0px;" alt=""/>
                                  <h1>Oops! No Survey Found</h1>
                                  </center>
                              </div>
                          </div>
                      </div>
            </div>
            <?php } else {
               while ($result = mysqli_fetch_array($select)){
               $survey_id_temp[] = $result['survey_id'];
               }
               $survey_id_temp1 = array();
               $select = "SELECT * FROM survey_received WHERE user_id = $id ORDER BY `survey_id` ASC";
               $select = mysqli_query($con_survey, $select) or die(mysqli_error($con_survey));
               while ($result = mysqli_fetch_array($select)){
                $survey_id_temp1[] = $result['survey_id'];
               }
               $count = 0 ;
               $survey_id_main = $survey_id_temp ;
               foreach ($survey_id_temp as $value) {
               foreach($survey_id_temp1 as $value1){
               if($value == $value1){
               unset($survey_id_main[$count]);
               }
               }
               $count++;
               }
               if(sizeof($survey_id_main) > 0){?>
            <div class="col-xs-12">
               <h2 style="font-family: 'Arial,sans-serif'; font-size: 36px;">Surveys Available</h2>
            </div>
            <div class="col-xs-12">
               <div style="overflow-x: auto;">
                  <table>
                     <thead>
                        <tr>
                           <th id="no"> </th>
                           <th id="title">Title</th>
                           <th id="point">Points</th>
                           <th id="ques">Total Questions</th>
                           <th id="enter" style="border-right: 0px ;"> </th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php
                           $select = "SELECT * FROM `survey_main` where survey_id in (".implode(',',$survey_id_main).")";
                           $select = mysqli_query($con_survey, $select) or die(mysqli_error($con_survey));
                           $count = 0;
                           while ($result_survey = mysqli_fetch_array($select)) {
                           $survey_id_page = $result_survey['survey_id'];
                           $survey_title_page = $result_survey['survey_heading'];
                           $survey_point = $result_survey['survey_point'];
                           $survey_questions_count = $result_survey['total_question'];
                            $count = $count+1; ?>
                        <tr class="survey_list">
                           <td><?php echo $count ?></td>
                           <td class="titles"><?php echo $survey_title_page; ?></td>
                           <td><?php echo $survey_point; ?></td>
                           <td><?php echo $survey_questions_count; ?></td>
                           <td style="border-right: 0px ;" href="#confirm_modal" data-toggle="modal" data-survey-id="<?php echo $survey_id_page;?>" ?><a style="color: rgb(0,0,0);">Participate</a></td>
                        </tr>
                        <?php } ?>
                     </tbody>
                  </table>
               </div>
            </div>
            <?php } else{ ?>
                  <div class="col-xs-12">
                 <div class="container" style="paddin-top:100px;">
                          <div class="row">
                              <div class="col-xs-12" style="">
                                  <center>
                                  <img src="design/image/emoj.gif" style="width: 50%; padding: 0px;height: 100%; margin: 0px;" alt=""/>
                                  <h1>Oops! No Survey Found</h1>
                                  </center>
                              </div>
                          </div>
                      </div>
            </div>
           <?php }}  ?>
         </div>
      </div>
       <div class="modal fade" id="confirm_modal">
           <div class="modal-dialog">
         <div class="modal-content">
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Please Accept Terms & Conditions</strong></h3>
               </center>
             </div>
             <div class="modal-body">
                 <center>
                     <form method="POST">
                         <div style="display:none; padding-top:20px;">
                         <input type="number" name="sid" id="sid" value="" required>
                         </div>
                         <div style="padding-top:20px;">
                             <input type="checkbox" name="tc" required>&nbsp;You Accept Our Terms & Conditions
                         </div><br><br>
                          <div style="text-align: center">
                              <center> 
                                  
                                  <input type="submit" id="next_survey" name="next_survey" class="logbtn" value="Submit">
                              </center>
                           </div>
                     </form>
                 </center>
             </div>
         </div>
           </div>
       </div>
   </body>
</html>
<script type="text/javascript" src="design\js\page_animation.js"></script>
<script>
         $(document).ready(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
  document.getElementById("loads").style.display="block";
  document.getElementById("main").style.display="none";
  setTimeout("hide()", 2000);
});
function hide() {
    document.getElementById("loads").style.display="none";
    document.getElementById("main").style.display="block";
}
    $('#confirm_modal').on('show.bs.modal', function(e) {
    var survey = $(e.relatedTarget).data('survey-id');
    $(e.currentTarget).find('input[name="sid"]').val(survey);
});
</script>
<?php 
if(isset($_POST['next_survey'])){
   if(isset($_POST['tc'])){
       $sid = $_POST['sid'];
       $sid = mysqli_real_escape_string($con_survey, $sid);
       $_SESSION['sid'] = $sid;
       echo ("<script>location.href='survey_participate.php'</script>");
   } else {
       echo ("<script>alert('Please Accept Terms & Conditions')</script>");
   }
}
?>