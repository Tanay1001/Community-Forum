<?php
   if(isset($_POST['submit_pass'])){
       $old_pass = $_POST['o_password'];
       $old_pass = mysqli_real_escape_string($con, $old_pass);
       $old_pass = MD5($old_pass);   
       $new_pass = $_POST['n_password'];
       $new_pass = mysqli_real_escape_string($con, $new_pass);
       $new_pass1 = $_POST['n_a_password'];
       $new_pass1 = mysqli_real_escape_string($con, $new_pass1);
       $regex_password = "/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/";
       if(!preg_match($regex_password, $new_pass) && !preg_match($regex_password, $new_pass1)){
               echo "<script>alert('Please Match the requested format for new password')</script>";
       } elseif ($new_pass !== $new_pass1) {
               echo "<script>alert('New Password are not matching')</script>";        
       } else {
               $query = "SELECT * FROM users WHERE user_email ='" . $_SESSION['user_email'] . "'";
               $result = mysqli_query($con, $query) or die($mysqli_error($con));
               $fetch = mysqli_fetch_array($result);
               $orig_pass = $fetch['user_password'];
               if($old_pass == $orig_pass){
                               $np = md5($new_pass);
                               $query1 = "UPDATE  users SET user_password = '" . $np . "' WHERE user_email = '" . $_SESSION['user_email'] . "'";
                               $r = mysqli_query($con, $query1) or die($mysqli_error($con));
                               if($r){
                                   require 'email_password.php';
                                       echo "<script>alert('Password Updated')</script>";
                                       echo ("<script>location.href='account_details.php?user_id=$id'</script>");
                               }else{
                                       echo "<script>alert('Try Again')</script>";
                                       echo ("<script>location.href='account_details.php?user_id=$id'</script>");
                               }
               } else{
                   echo "<script>alert('Old Password is incorrect')</script>";
                   echo "<script>self.location='account_details.php?user_id=$id'</script>";
               }
       }
   }
   ?>
<br><span style="font-weight: 700;">
    <a data-target="#pass" data-toggle="modal" style="color: rgb(0,0,0);">Change Password</a>
</span>
   <div class="modal fade" id="pass">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Change Your Password</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                  <form class="login-form" onsubmit="return validation()" method="POST">
                     <div class="txtb">
                        <label for="o_password">Enter Your Old Password</label><br>
                        <input type="password" name="o_password" id="o_password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$"  required>
                        <span></span>
                     </div>
                     <div class="txtb">
                        <label for="n_password">Enter Your New Password</label><br>
                        <input type="password" name="n_password" id="n_password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$"  required>
                        <span></span>                       
                     </div>
                     <div class="txtb">
                        <label for="n_a_password">Enter Your New Password Again</label><br>
                        <input type="password" name="n_a_password" id="n_a_password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$"  required>
                        <span></span>
                     </div>
                     <div style="text-align: center">
                        <center> <input type="submit" class="logbtn" name="submit_pass" value="Change Your Password"> </center>
                     </div>
                  </form>
                  <p style="color: rgb(255,0,0);">Password Should be of length 8-20 with atleast 1 Uppercase Letter,
                     atleast 1 Lowercase Letter, atleast 1 Digit, atleast 1 Special Character
                  </p>
               </center>
            </div>
         </div>
      </div>
   </div>

<script>
function validation(){
var n_password = document.getElementById('n_password').value;
var n_a_password = document.getElementById('n_a_password').value;
if(n_password !== n_a_password){
alert("New Password Are not matching");
return false;
}
}
</script>