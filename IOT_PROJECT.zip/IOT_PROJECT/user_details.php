<div class="col-xs-12 col-sm-4" style="padding-top:20px;">
    <p style="font-size: 16px; line-height: 2.2;">
        <?php 
                require 'user_country.php'; 
                require 'user_interest.php';
                if($users_email == $email){ 
                    require 'user_email.php'; 
                    require 'user_password.php'; 
                } 
        ?>
    </p>
</div>