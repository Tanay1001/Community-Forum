<?php
session_start();
require("includes/connection.php");
if(isset($_SESSION['user_email'])){
    $email = $_SESSION['user_email'];
    $id = $_SESSION['user_id'];
}
function GetImageExtension($imagetype){
		if(empty($imagetype)) return false;
		switch($imagetype){
			case 'image/bmp': return '.bmp';
			case 'image/gif': return '.gif';
			case 'image/jpeg': return '.jpg';
			case 'image/png': return '.png';
			default: return false;
		}
	}
if(isset($_POST['submit_question_answer'])){
    if (empty($_FILES["uploadedimage"]["name"])){
    $ans = $_POST['answer_form'];
    $ans = mysqli_real_escape_string($con, $ans);
    $ques_id = $_POST['qid'];
    $ques_id = mysqli_real_escape_string($con, $ques_id);
    $count = 0;
    $split = explode(" ", $ans);
    for($i = 0; $i < count($split); $i++){
        if($split[$i] != ""){
            $count += 1;
        }
    }
   if($count >= 50){
       $query = "INSERT INTO answer(question_id, user_id, answer)VALUES('" . $ques_id . "','" . $id . "','" . $ans . "')";
       $check = mysqli_query($con, $query) or die(mysqli_error($con));
       if($check){
           $answer_id = mysqli_insert_id($con);
           $sel_qu = "select * from question where id = '$ques_id'";
           $sel_qu = mysqli_query($con, $sel_qu) or die(mysqli_error($con));
           $row_qu = mysqli_fetch_array($sel_qu);
           $count = $row_qu['total_answer'] + 1;
           $sel_qu = "update question SET total_answer = '$count' where id = '$ques_id'";
           $sel_qu = mysqli_query($con, $sel_qu) or die(mysqli_error($con));
           if($sel_qu){
               include 'email_answer.php';
               echo "<script>alert('Answer Submitted Successfully')</script>";
               echo "<script>self.location='answer_view_main.php?id=$answer_id&qid=$ques_id'</script>";
           } else {
               $del = "delete from answer where id='$answer_id'";
               $del = mysqli_query($con, $del);
               echo"<script>alert('Please Try Again')</script>";
               echo "<script>self.location='answer_view.php?id=$ques_id'</script>";
           }
       } else {
           echo"<script>alert('Please Try Again')</script>";
           echo "<script>self.location='answer_view.php?id=$ques_id'</script>";
       }
   }
    } else{
        $file_name=$_FILES["uploadedimage"]["name"];
		$temp_name=$_FILES["uploadedimage"]["tmp_name"];
		$imgtype=$_FILES["uploadedimage"]["type"];
		$ext= GetImageExtension($imgtype);
                if($ext != false){
		$imagename=date("d-m-Y")."-".time().$ext;
		$target_path = "design/image_answer/".$imagename;
                if(move_uploaded_file($temp_name, $target_path)){
           $ans = $_POST['answer_form'];
    $ans = mysqli_real_escape_string($con, $ans);
    $ques_id = $_POST['qid'];
    $ques_id = mysqli_real_escape_string($con, $ques_id);
    $count = 0;
    $split = explode(" ", $ans);
    for($i = 0; $i < count($split); $i++){
        if($split[$i] != ""){
            $count += 1;
        }
    }
   if($count >= 50){
       $query = "INSERT INTO answer(question_id, user_id, answer,image)VALUES('" . $ques_id . "','" . $id . "','" . $ans . "','" . $target_path . "')";
       $check = mysqli_query($con, $query) or die(mysqli_error($con));
       if($check){
           $answer_id = mysqli_insert_id($con);
           $sel_qu = "select * from question where id = '$ques_id'";
           $sel_qu = mysqli_query($con, $sel_qu) or die(mysqli_error($con));
           $row_qu = mysqli_fetch_array($sel_qu);
           $count = $row_qu['total_answer'] + 1;
           $sel_qu = "update question SET total_answer = '$count' where id = '$ques_id'";
           $sel_qu = mysqli_query($con, $sel_qu) or die(mysqli_error($con));
           if($sel_qu){
               include 'email_answer.php';
               echo "<script>alert('Answer Submitted Successfully')</script>";
               echo "<script>self.location='answer_view_main.php?id=$answer_id&qid=$ques_id'</script>";
           } else {
               $del = "delete from answer where id='$answer_id'";
               $del = mysqli_query($con, $del);
               echo"<script>alert('Please Try Again')</script>";
               echo "<script>self.location='answer_view.php?id=$ques_id'</script>";
           }
       } else {
           echo"<script>alert('Please Try Again')</script>";
           echo "<script>self.location='answer_view.php?id=$ques_id'</script>";
       }
   }
    }
    }
    }
}
?>
