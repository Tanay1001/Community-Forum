<div class="col-xs-12 col-sm-offset-1 col-sm-4" style="padding-top:20px;">
    <div class="change_show"><h4 style="display:inline;"><strong>About Me</strong></h4>
        <?php if(isset($_SESSION['user_email']) && $_SESSION['user_email'] == $num['user_email']){ ?>
        <a class="change" data-target="#bio" data-toggle="modal">Change Bio</a>
            
   <div class="modal fade" id="bio">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Change Your Country</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                  <form class="login-form" method="POST">
                    
                        <label for="name_form">Enter Your Bio</label><br>
                        <textarea required name="summary" id="sum"  rows="8" cols="40" ></textarea>
                      
                    
                     <div style="text-align: center">
                         <center> <input type="submit" id="submit_bio" name="submit_bio" class="logbtn" value="Update Bio"> </center>
                     </div>
                  </form>
               </center>
            </div>
         </div>
      </div>
   </div>
      <?php } ?> 
    </div>
    <p style="padding-top:15px; font-size: 16px; line-height: 2.2; word-break: break-word;">
        <?php echo $userbio; ?>
    </p>
</div>
<?php
   if(isset($_POST['submit_bio'])){
       if(!empty($_POST['summary'])){
       $name_form = $_POST['summary'];
       $name_form = mysqli_real_escape_string($con, $name_form);
       $select = "update users SET user_bio = '$name_form' where user_id = '$id' ";
       $result = mysqli_query($con, $select) or die($mysqli_error($con));
       if($result){
           echo "<script>alert('Bio Updated')</script>";
           echo "<script>self.location='account_details.php?user_id=$id'</script>";
       } else {
           echo "<script>alert('Try Again')</script>";
           echo "<script>self.location='account_details.php?user_id=$id'</script>";        
       }
   }
   }
   ?>
 