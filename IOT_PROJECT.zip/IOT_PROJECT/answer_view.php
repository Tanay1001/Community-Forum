<?php
   require("includes/connection.php");
   session_start();
    function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
   //whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return bin2hex($ip);  
    }
   
   if (!isset($_SESSION['user_email'])) {
      $id = 0;
      $id_ip = getIPAddress();
   } else {
       $email = $_SESSION['user_email'];
       $id_ip = getIPAddress();
       $id = $_SESSION['user_id'];
   }
   
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <script type="text/javascript" src="design/js/validation.js" ></script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Forumex</title>
      <style>
         .main-card{
         width: 100%;
         height: auto;
         margin-top: 10px;
         margin-bottom: 50px;
         font-family: 'Arial,sans-serif';
         font-size: 24px;
         border-radius: 5px;
         background-color: rgb(255,255,255);
         }
         .question-card{
         padding: 20px;
         padding-bottom: 0xp;
         height: 100%;
         }
         .list_question_detail{
         padding: 0px;
         padding-right: 5px;
         text-align:right; 
         position:relative;
         }
         .answer-card{
         padding: 10px;
         font-size: 18px;
         line-height: 20px;
         }
         .side_question-card{
         width: auto;
         height: 100%;
         line-height: 20px; 
         padding: 20px 5px 10px 20px; 
         }
         .show_answer{
             border-left: 1px solid rgb(0,0,0); 
             padding: 10px;
         }
          .answer-card:hover{
             background-color:#f8f8ff;
         }
         @media(min-width:300px){
         .list_question_detail{
         font-size: 10px;
         }
         .side_question-card{
         font-size: 12px;
         }
         }
         @media(min-width:500px){
         .list_question_detail{
         font-size: 14px;
         }
         .side_question-card{
         font-size: 14px;
         }
         }
      </style>
   </head>
   <body>
      <?php
         require 'includes/home_header.php';
          ?>
      <div class="container zoom" style="padding-top: 100px;">
         <?php 
            if(isset($_GET['id'])){
                $ques_id = $_GET['id'];
                $sel_question = "select * from question where id='$ques_id'";
                $sel_question = mysqli_query($con, $sel_question);
                if(mysqli_num_rows($sel_question) == 1){
                     $sel = "select * from question_view where user_ip = '$id_ip' and ques_id = '$ques_id'";
                     $sel = mysqli_query($con, $sel);
             if(mysqli_num_rows($sel) == 0){
                 $add_viewer = "insert into question_view(ques_id,user_id,user_ip)VALUES('$ques_id','$id','$id_ip')";
                 $add_viewer = mysqli_query($con, $add_viewer);
                 if($add_viewer){
                     $row = mysqli_fetch_array($sel_question);
                     $visitor = $row['total_visitor'] + 1;
                     $update_visitor = "update question SET total_visitor = '$visitor' where id='$ques_id'";
                     $update_visitor = mysqli_query($con, $update_visitor);
                 }
             }
             $sel = "select * from question where id='$ques_id'";
             $sel = mysqli_query($con, $sel);
             $row = mysqli_fetch_array($sel);  
             if($row['total_answer'] > 0){ 
             $sel_answer = "select * from answer where question_id='$ques_id'";
             $sel_answer = mysqli_query($con, $sel_answer); ?>
         <div class="row">
            <div class="col-xs-12 col-sm-offset-1 col-sm-10">
               <div class="main-card">
                  <div class="question-card">
                     <div style="font-size:14px ">Question:</div>
                     <?php echo $row['question']; ?>
                     <div class="list_question_detail">
                        <?php echo $row['total_answer']." Answers,"; ?>
                        <?php echo $row['total_visitor']." Visitors"; ?>
                        <?php if(isset($_SESSION['user_id'])){ ?>,<a href="#answer_modal" data-toggle="modal" style="color:rgb(0,0,0);">Add an Answer</a><?php } ?>
                     </div>
                  </div>
                  <?php  $count = 0; while ($rows = mysqli_fetch_array($sel_answer)){
                     $num_words = 50;
                     $words = array();
                     $words = explode(" ", nl2br($rows['answer']), $num_words);
                     $shown_string = "";
                     if(count($words) == 50){
                         $ans_id = $rows['id'];
                         $qids = $rows['question_id'];
                     $words[49] = "<a href='answer_view_main.php?id=$ans_id&qid=$qids'>Read More</a>";
                     }
                     $shown_string = implode(" ", $words);
                     $count++;?>         
                  <div class="answer-card">
                     <div class="row" style="display: flex;width:100%; height: 100%; overflow: auto;">
                         <div class="col-xs-4 col-sm-2 side_question-card">
                           <?php echo $rows['total_visitor']." Views";?><br> 
                           <a type="button" value="Share" onclick="Copy(<?php echo $count?>);" style="background-color: transparent; border: none; color: rgb(0,0,0);" >Share</a>               
                           <input id="url<?php echo $count?>" style="display:none;"value="<?php echo "http://localhost/IOT_PROJECT/answer_view_main.php?id=".$ans_id."&qid=".$qids;?>">
                        </div>
                        <div class="col-xs-9 col-sm-10 show_answer">
                           Answer <?php echo $count; ?>:
                           <div style="width:100%;"><?php echo $shown_string; ?></div>
                        </div>
                     </div>
                  </div>
                  <?php    } ?>
               </div>
            </div>
         </div>
         <?php } else { ?>
         <div class="row">
            <div class="col-xs-12 col-sm-offset-1 col-sm-10">
               <div class="main-card">
                  <div class="question-card">
                     <div style="font-size:14px ">Question:</div>
                     <?php echo $row['question']; ?>
                     <div class="list_question_detail">
                        Total Answers:<?php echo $row['total_answer']; ?>
                        Visitors:<?php echo $row['total_visitor']; ?>
                     </div>
                  </div>
                  <center>
                     <h2>Oops! No Answer Found</h2>
                     <?php if(isset($_SESSION['user_id'])){?>
                     <h2><a href="#answer_modal" data-toggle="modal" style="color:rgb(0,0,0);">Add an Answer</a></h2>
                     <?php } ?>
                  </center>
               </div>
            </div>
         </div>
         <?php    }
            } else { ?>
         <div class="row">
            <div class="col-xs-12">
               <center>
                  <h2>Oops! No Question Found</h2>
               </center>
            </div>
         </div>
         <?php   } } else { ?>
         <div class="row">
            <div class="col-xs-12">
               <center>
                  <h2>Oops! No Question Found</h2>
               </center>
            </div>
         </div>
         <?php   }
            ?>
      </div>
      <?php if(isset($_SESSION['user_id'])){ ?>
      <div class="modal fade" id="answer_modal">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal"> &times;</button>
                  <center>
                     <h3><strong>Add Answer to the Question</strong></h3>
                  </center>
               </div>
               <div class="modal-body">
                  <center>
                     <form id="my-form" action="answer.php" onsubmit="return validation_answer()" enctype="multipart/form-data" method="POST" style="width:100%;">
                        <p id="error_msg" style="color:rgb(255,0,0);"></p>
                        <input type="int" id="qid" name="qid" required style="display:none;" value="<?php echo $ques_id;?>">
                        <div>
                           <label for="name_form">Enter Your Answer (Min. 50 Words) :</label><br>
                           <center><textarea name="answer_form" id="answer_form" style="width:100%; height: 200px;" required></textarea>
                           </center>
                        </div>
                        <div class="txtb">
                         <label for="text">Upload Photo</label><br>
			 <input type="file" class="form-control" name="uploadedimage">
                         <span></span>
		     </div>
                        <div style="text-align: center">
                           <center> <input type="submit" name="submit_question_answer" class="logbtn" style="font-size: 18px;" value="Submit Answer"> </center>
                        </div>
                     </form>
                  </center>
               </div>
            </div>
         </div>
      </div>
      <?php } ?>
   </body>
</html>
<script type="text/javascript" src="design\js\form_animation.js"></script>
<script type="text/javascript" src="design\js\page_animation.js"></script>
<script>
   function Copy(count) {
     /* Get the text field */
   var copyText = document.getElementById('url'+count);
   
   /* Select the text field */
   console.log(copyText.value);
   copyText.select();
   copyText.setSelectionRange(0, 99999); /* For mobile devices */
   
   /* Copy the text inside the text field */
   navigator.clipboard.writeText(copyText.value);
   
   /* Alert the copied text */
   alert("Link Copied");
   }
   function validation_answer(){
    var answerss = document.getElementById('answer_form').value;
    var counts = validate_answers(answerss);
    if(counts >= 50){
        return true;
    } else {
       document.getElementById("error_msg").innerHTML = "Min. 50 Words*";
        return false;
    }
   }
</script>