<div class="modal fade" id="forgot-password">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Forgot Password</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                  <p id="error_message_question" style="color:rgb(255,0,0); font-size: 12px;"></p>
                  <form  onsubmit="return validation_email()" action="forgot-form-submit.php" style="width: 50%;" method="POST">
                     <div class="txtb">
                        <label for="question_form">Enter Your Registered Email-Id : </label><br>
                        <input type="email" name="password_email" id="password_email" >
                        <span></span>
                     </div>
                     <div style="text-align: center">
                        <center> <input type="submit" id="password_submit" name="password_submit" class="logbtn" value="Submit"> </center>
                     </div>
                  </form>
               </center>
            </div>
         </div>
      </div>
</div>
<script>
    function validation_email(){
var email = document.getElementById('password_email').value;
if(validate_email(email)){
    if(validate_email_pattern(email)){
        return true;
    } else{
        alert("Please Enter Valid Email-Id");
        return false;
    } 
    } else{
    alert("Please Enter Email-Id");
        return false;
    }
    }
</script>