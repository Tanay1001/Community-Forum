<?php
   require("includes/connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
      $email = null;
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       $sel = "SELECT * FROM users WHERE user_id= '$id'";
       $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
       $row= mysqli_fetch_array($sel1);
       $users_interest = $row['user_interest'];
       $users_bio = $row['user_bio'];
       if( $users_interest == null){
           echo ("<script>location.href='user_interest_form.php'</script>");
       } elseif ($users_bio == null) {
       echo ("<script>location.href='user_bio_form.php'</script>");
   }
      $userbio = $row['user_bio'];
   $user_bio = explode(',', $userbio);
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <script type="text/javascript" src="design\js\validation.js"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Account Details | Forumex</title>
      <style>
         .modal-header{
         border-bottom: 1px solid #EBEBEB;
         color:rgb(255,255,255); 
         background-color: #3333FF; 
         }
         .close{
         color:rgb(0,0,0);
         font-weight: bold;
         font-size:50px;
         }
         form {
         position: relative;
         width: 200px;
         }
         input{
         text-align: center;
         }
         .user_profile{
             border-radius: 50%;
         }
         .user_profile:hover{
            background-color: rgba(0,0,0,0.1);
         }
      </style>
   </head>
   <body style="padding-top: 100px; background-color: rgb(255,255,255);">
      <?php
         require 'includes/home_header.php';
          ?>
       <div class="container" style="font-family: 'Arial,sans-serif';">
         <div class="row zoom">
             <div class="col-xs-12">
              <?php if(isset($_GET['user_id'])){
                  $sel = "SELECT * FROM users WHERE user_id= '".$_GET['user_id']."'";
                  $sel2 = mysqli_query($con, $sel) or die(mysqli_error($con));
                  $row= mysqli_num_rows($sel2);
                  if($row == 0){ ?>
                      <p style="text-align:center; font-size: 25px;">Oops! No User Found</p>
                 <?php } else{ 
                     $num = mysqli_fetch_array($sel2);
                     $users_name = $num['user_name'];
                     $users_email = $num['user_email'];
                     $user_interest = $num['user_interest'];
                     $userbio = $num['user_bio'];
                     $user_bio = explode(',', $userbio);
                     require 'user_profile.php';
                     ?>
                      <div class="row" style="padding-top:40px;">
                          <div class="col-xs-12 col-sm-4">
                              <h4>Details</h4>
                              <p style="padding-top:15px; font-size: 16px; line-height: 2.2;">
                                  <?php require 'user_name.php'; 
                                        require 'user_country.php'; 
                                        require 'user_interest.php';
                                     if($users_email == $email){ 
                                     require 'user_email.php'; 
                                     require 'user_password.php'; 
                                   } ?>
                              </p>
                          </div>
                          <div class="col-xs-10 col-xs-offset-1 col-sm-offset-0 col-sm-3">
                              <img class="user_profile" src="design/image/no_img_profile.png" alt=""/>
                          </div>
                          <div class="col-xs-12 col-sm-5">
                              <h4 class="bio">About Me</h4>
                              <p style="padding-top:15px; font-size: 16px; line-height: 2.2; word-break: break-word;">
                                  <?php echo $user_bio[1]; ?>
                              </p>
                          </div>
                      </div>
                   <?php    }
                     ?>
               <?php      
                 }
                  ?>
             </div>
            <!-- <div class="col-xs-12 col-sm-offset-1 col-sm-10 col-md-offset-1 col-md-9">
                 <p style="text-align:center; font-size: 25px;"><a  href="help.php" target="_blank" style="color:rgb(0,0,0);">Need Any Help,Click Here</a></p> -->
            </div>
         </div>
   </body>
</html>
<script type="text/javascript" src="design\js\form_animation.js"></script>
<script type="text/javascript" src="design\js\page_animation.js"></script>
