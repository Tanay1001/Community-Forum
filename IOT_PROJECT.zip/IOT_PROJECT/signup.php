<?php
   session_start();
   require("includes/connection.php");
   if (isset($_SESSION['user_email'])) {
       header('location: home.php?answered');
   }
   ?>
<?php
   function codegenereator(){
       require("includes/connection.php");
       $token = bin2hex(random_bytes(15));
       $querys = "SELECT * FROM users WHERE token='$token'";
       $results = mysqli_query($con, $querys)or die(mysqli_error($con));
       if(mysqli_num_rows($results) > 0){
           codegenereator();
       } else {
           return $token;    
       }
   }
   $error = null;
    if(isset($_POST['submit'])){
        if( !empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['password']) )
   {
   	$name = $_POST['name'];
   	$name = mysqli_real_escape_string($con, $name);
   	
   	$email = $_POST['email'];
   	$email = mysqli_real_escape_string($con, $email);
   	
   	$password = $_POST['password'];
   	$password = mysqli_real_escape_string($con, $password);
   	
   	$regex_email = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/";
   	$regex_password = "/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/";
   	
   	$query = "SELECT * FROM users WHERE user_email='$email'";
   	$result = mysqli_query($con, $query)or die(mysqli_error($con));
   	$num = mysqli_num_rows($result);
   
   	if ($num != 0) {
   		$error = "Email Already Exists*";
   	} else if (!preg_match($regex_email, $email)) {
   		$error = "Not a Valid Email-Id";
   	} else if (!preg_match($regex_password, $password)) {
   		$error = "Password Should be of length 8-20 with Atleast 1 Uppercase Letter, Atleast 1 Lowercase Letter, Atleast 1 Digit, Atleast 1 Special Character";
   	}  
   	else {
                $token = codegenereator();
   		$password = MD5($password);
   		$query = "INSERT INTO users(user_name, user_email, user_password,token)VALUES('" . $name . "','" . $email . "','" . $password . "','" . $token . "')";
   		$check=mysqli_query($con, $query) or die(mysqli_error($con));
   		if($check){
   			$user_id = mysqli_insert_id($con);
   			require 'email_activate.php';
   		}
   		else{
   			$error = "Some error occurred. Please try again.";
   		}
   	}
   }
   else{
   	$error = "Enter Valid Details*";
   }
    }
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <script type="text/javascript" src="design\js\validation.js"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Sign Up | FORUMEX</title>
      <style>
         .content{
         min-height: 300px;
         padding-top: 100px;
         padding-bottom: 20px;
         }
         .panel{
         box-shadow: 0 15px 15px 0 rgba(0, 0, 0, 0.2);
         }
         form {
         position: relative;
         width: 200px;
         }
         input{
         text-align: center;
         }
         @media(min-width:320px){
         .texts{
         text-align: center;
         }
         }
         @media(min-width:761px){
         .texts{
         text-align: initial;
         }
         .glyphicon-comment,.glyphicon-gift,.glyphicon-star,.glyphicon-tags{
         color:#3333FF;
         }
         td,.glyphicon{
         font-size: 15px;
         }
         }
         @media(min-width:991px){
         .glyphicon{
         font-size: 17px;
         }
         }
      </style>
   </head>
   <body>
      <?php require 'includes/home_header.php'; ?>
      <div class="content">
         <div class="container">
            <div class="row equal">
               <div class="col-xs-offset-1 col-xs-10 col-sm-offset-0 col-sm-6 left" style="padding:0 ">
                  <div class="log-left" >
                     <div class="texts">
                        <h2>Join the Forumex Community</h2>
                        <div class="visible-lg visible-sm visible-md">
                           <br>
                           <table>
                              <tbody>
                                 <tr>
                                    <td>
                                       <div class="glyphicon glyphicon-comment"></div>
                                       &nbsp;&nbsp;Get Unstuck - Ask a Question
                                    </td>
                                 </tr>
                                 <tr>
                                    <td><br></td>
                                 </tr>
                                 <tr>
                                    <td>
                                       <div class="glyphicon glyphicon-star"></div>
                                       &nbsp;&nbsp;Unlock New Privileages like Voting and Commenting
                                    </td>
                                 </tr>
                                 <tr>
                                    <td><br></td>
                                 </tr>
                                 <tr>
                                    <td>
                                       <div class="glyphicon glyphicon-tags"></div>
                                       &nbsp;&nbsp;Follow your Favorite Person and Spaces
                                    </td>
                                 </tr>
                                 <tr>
                                    <td><br></td>
                                 </tr>
                                 <tr>
                                    <td>
                                       <div class="glyphicon glyphicon-gift"></div>
                                       &nbsp;&nbsp;Earn Reputation and Money
                        </div>
                        </td>
                        </tr>
                        </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
            <div class="  col-xs-offset-1 col-xs-10 col-sm-offset-0 col-sm-4 right" style="padding:0; ">
               <div class="panel" >
                  <div class="panel-heading" style="text-align: center; border-bottom: 1px solid #EBEBEB;">
                     <h4>Sign Up</h4>
                  </div>
                  <div class="panel-body">
                     <center>
                        <p id="error_message" style="color:rgb(255,0,0); font-size: 12px;"><?php echo $error;?></p>
                        <form onsubmit="return doValidate()"  id="my-form"  method="POST" >
                           <div class="txtb">
                              <label for="name">Name:</label>
                              <center> <input name="name" id="name">
                                 <span></span>
                              </center>
                           </div>
                           <div class="txtb">
                              <label for="email">Email:</label>
                              <center><input  id="email"   name="email">
                                 <span></span>
                              </center>
                           </div>
                           <div class="txtb">
                              <label for="password">Password:</label>
                              <center>  	<input type="password" id="password" name="password" >
                                 <span ></span>
                              </center>
                           </div>
                           <div style="text-align: center">
                              <center> <input type="submit" class="logbtn" name="submit" id ="submit" value="Sign Up"> </center>
                           </div>
                        </form>
                        <br>
                        <a href="login.php" style="color: rgb(0,0,0);">
                           <p>Already have a Account,Login Here</p>
                        </a>
                     </center>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
   </body>
</html>
<script type="text/javascript" src="design\js\form_animation.js"></script>
<script type="text/javascript" src="design\js\page_animation.js"></script>
<script>
   function doValidate(){
       var email = document.getElementById('email').value;
       var name = document.getElementById('name').value;
       var password = document.getElementById('password').value;
       if(email == "" && name=="" && password == ""){
           document.getElementById("error_message").innerHTML = "All Fields are Required*";
           return false;
       }        
       if(validate_name(name)){
         if(validate_email(email)){
           if(validate_email_pattern(email)){
             if(validate_passoword(password)){
               if(validate_password_pattern(password)){
                   return true;
               } else{
                   document.getElementById("error_message").innerHTML = "Password Should be of length 8-20 with Atleast 1 Uppercase Letter, Atleast 1 Lowercase Letter, Atleast 1 Digit, Atleast 1 Special Character";
           return false;
               }
             } else{
                 document.getElementById("error_message").innerHTML = "Please Enter Password*";
                 return false;
             }
          } else{
              document.getElementById("error_message").innerHTML = "Enter Valid Email*";
              return false;
          }    
        } else{
            document.getElementById("error_message").innerHTML = "Enter Email*";
            return false;
        }            
       } else{
           document.getElementById("error_message").innerHTML = "Please Enter Name*";
           return false;
       }
   }
</script>