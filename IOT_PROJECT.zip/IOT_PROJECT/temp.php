<?php
   session_start();
   require("includes/connection.php");
   // Redirects the user to Home page if he/she is logged in.
   if (isset($_SESSION['user_email'])) {
       header('location: home.php?answered');
   } 
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title><?php echo "FORUMEX | One Stop Destination to Every Doubt"; ?></title>
      <style>
          html{
              scroll-behavior: smooth;
          }
         body{
         margin: 0;
         font-family: 'Arial,sans-serif';
         padding: 0;
         max-width:100%;
         overflow-x: hidden;
         }
            #loads{
               background: url('design/image/Forumex Loading.gif') no-repeat center center;
               position: absolute;
               top: 0;
               left: 0;
               height: 100%;
               width: 100%;
               z-index: 9999999;
          }
        
         .nav>li>a{
         color: rgb(255,255,255);
         }
         .nav>li>a:focus, .nav>li>a:hover{
         text-decoration: none;
         background-color: rgba(0,0,0,0.2);
         background-size: 50px;
         margin-top: 5px; margin-bottom: 5px;
         padding-top: 5px; 
         border-radius: 100px;
         color: rgb(255,255,255);
         text-shadow: 5px 5px rgb(0,0,0,0.2);
         }
         .icon-bar{
         background-color: rgb(255,255,255);
         }
         #content{
              color:rgb(255,255,255);
         }
         h1,h2{
             font-family: cursive;
         }
         .but{
          width: 100px;
         margin-top: 10px;
         padding: 5px 10px 5px 10px;
         color:rgb(255,255,255);
         background-color: rgb(0,0,0);
         }
         @media(min-width:300px){
              #content > h1{
             font-size: 36px;
         }
         }
         @media(min-width:500px){
              #content > h1{
             font-size: 44px;
         }
         }
         @media(min-width:750px){
              #content > h1{
             font-size: 60px;
         }
         }
      </style>
   </head>
   <body>
       <div id="loads"></div>
<div id="cont">
       <div class="container-fluid" style="background-color: #65a6ff;">
         <div class="navbar" style="background: transparent; border: 0; padding-top:20px;">
            <div class="container">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle" style="background-color: rgb(0,0,0,0.2);" data-toggle="collapse" data-target="#myNavbar">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>                        
                  </button>
                  <b><a class="navbar-brand" style="font-size: 36px;color: rgb(255,255,255); text-shadow: 5px 5px rgb(0,0,0,0.2)" href="index.php">Fourmex</a></b>
               </div>
               <div class="collapse navbar-collapse" style="border:0;" id="myNavbar">
                  <ul class="nav navbar-nav navbar-right">
                     <li><a href = "about.php"><span class = "glyphicon glyphicon-info-sign"></span> About Us</a></li>
                     <li><a href="signup.php" ><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                     <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                  </ul>
               </div>
            </div>
         </div>
           <div class="container zoom" style="height:100vh;">
            <center>
                <div class="container" style="padding-top: 140px;">
                    <div class="row"> 
                        <div class="col-xs-12" id="content">
                  <h1>Welcome to Community Forumex</h1>
                  <h3 style="font-size: 20px;">Platform To Share Knowledge and Earn Money</h3>
                  <a  href="#about"><button class="but" >Read More</button></a>
                        </div>
                    </div>
               </div>
            </center>
         </div>
       </div>
          <div class="container-fluid" style="background-color:rgb(0,0,0); ">
              <div class="row">
                  <div class="col-xs-12" style="padding: 20px; padding-top: 40px;">
                      <div class="container">
                          <div class="row" style="color:rgb(255,255,255)">
                          <div class="col-xs-12 col-sm-4 left" style="padding:10px;">
                              <img src="design/image_home/1.png" alt=""/>
                              <h3><strong>Multi-Purpouse</strong></h3>
                              <p style="font-size: 14px; word-wrap: break-word;">
                                  A Platform where people connect​,Communicate openly and honestly ,earn points
                                  by participating in paid Surveys
                              </p>
                          </div>
                          <div class=" col-xs-12 col-sm-4 " style="padding:10px;">
                              <img src="design/image_home/2.png" alt=""/>
                              <h3>​<strong>Learn, share, grow</strong></h3>
                              <p style="font-size: 14px; word-wrap: break-word;">
                                  Adopt a Growth Mindset. Be curious and eager to learn. Aim for ethical, 
                                  sustainable, long-term growth, both personally and in the company
                              </p>
                          </div>
                          <div class=" col-xs-12 col-sm-4 right" style="padding:10px;">
                              <img src="design/image_home/3.png" alt=""/>
                              <h3><strong>Great Quality</strong></h3>
                              <p style="font-size: 14px; word-wrap: break-word;">​
                                  Authentically serve our customers by empowering, listening and 
                                  collaborating with our fellow Fourmexrs.
                              </p>
                          </div>
                      </div>
                  </div>
                  </div>
              </div>
          </div>
       <div class="container-fluid" id="about" style="height:100vh; position: relative; ">
           <div class="row">
               <img src="design/image_home/4.jpeg" style="width:100%; height: 100vh;">
               <div class="row" style="position:relative;">
               <div class="col-xs-12 col-sm-offset-6 col-sm-5 " 
                    style="text-align: right; padding: 100px 100px 0px 30px; margin-top:-600px; ">
                   <h2 style="font-size:48px;">About Us</h2>
                   <p style=" font-size: 16px;word-wrap: break-word;">​Empowering the World to Help People through Collective Knowledge.
                       Our public platform serves 100 million people every month, making 
                       it one of the 50 most popular websites in the world. Founded in 2008, 
                       Fourmex’s public platform is used by nearly everyone who wants to learn, 
                       share their knowledge, collaborate, and build their careers.</p>
                   <div style="display:inline;">
                       <a  href="about.php"><button class="but" >Read More</button></a>
                       <a  href="signup.php"><button class="but" >Sign Up</button></a>
                   </div>
               </div>
           </div>
           </div>
       </div>
              <div class="container-fluid" style="height:100vh; position: relative; ">
           <div class="row">
               <img src="design/image_home/5.jpeg" style="width:100%; height: 100vh;">
               <div class="row" style="position:relative; text-align:center; padding: 0px; margin-top:-650px;">
               <div class="col-xs-12 col-sm-offset-3 col-sm-6" 
                    style=" ">
                   <h2 style="font-size:48px;"><strong>Why Use Our Platform?</strong></h2>
                   <h4>Authentically serve our customers by empowering, listening and collaborating with our fellow Forumexrs.</h4>                 
               </div>
           </div>
               <div class="row" style="position: relative; text-align: center;">
                  <div class="col-xs-12 col-sm-3">
                        <h1 style="color:#b9c1cc;">​<strong>100+ million​</strong></h1>
                           <p style="font-size: 16px;"><strong>​Monthly visitors to our network</strong></p>
                       </div>
                       <div class="col-xs-12 col-sm-3"  style="">
                           <h1 style="color:#b9c1cc;">​​<strong>21+ million</strong></h1>
                           <p style="font-size: 16px;"><strong>​Question Asked to-Date</strong></p>
                       </div>
                       <div class="col-xs-12 col-sm-3"  style="">
                           <h1 style="color:#b9c1cc;">​​<strong>13.6 Seconds</strong></h1>
                           <p style="font-size: 16px;"><strong>​​Average Time between New Questions</strong></p>
                       </div>
                       <div class="col-xs-12 col-sm-3"  style="">
                           <h1 style="color:#b9c1cc;">​​<strong>50.6+ Billion</strong></h1>
                           <p style="font-size: 16px;"><strong>​​Times a Person got Help</strong></p>
                       </div>
                   </div>
           </div>
       </div>
           <div class="container-fluid" style="background-color:rgb(0,0,0); ">
              <div class="row">
                  <div class="col-xs-12" style="padding: 20px; padding-top: 40px;">
                      <div class="container">
                          <div class="row" style="color:rgb(255,255,255)">
                              <div class="col-xs-12 col-sm-offset-3 col-sm-6">
                                  <center>
                                      <h2 style="font-size: 48px;">Learn, Share, Grow</h2>
                                      <h4 style="word-wrap: break-word; font-size: 20px;">​Adopt a Growth Mindset.
                                          Be curious and eager to learn. Aim for ethical, sustainable, long-term growth, 
                                          both personally and in the company.</h4>
                                  </center>
                              </div>
                      </div>
                  </div>
                  </div>
              </div>
          </div>
       <div class="container-fluid" style="background-color:#f2f2f2; height: 100vh;">
              <div class="row">
                  <div class="col-xs-12" style="padding: 20px; padding-top: 40px;">
                      <div class="container">
                          <div class="row">
                              <div class="col-xs-12 col-sm-offset-3 col-sm-6">
                                  <center>
                                      <h2 style="font-size: 48px;">Our <strong>Review</strong></h2>
                                     
                                  </center>
                              </div>
                      </div>
                  </div>
                  </div>
              </div>
          </div>
       
      <div class="container-fluid" style="background-color:rgb(0,0,0); ">
              <div class="row">
                  <div class="col-xs-12" style="padding: 20px; padding-top: 40px;">
                      <div class="container">
                          <div class="row">
                              <div class="col-xs-12 col-sm-offset-3 col-sm-6">
                                  <center>
                                      <h2 style="font-size: 48px; color: rgb(255,255,255);">Try This Now!</h2>
                                      <a  href="signup.php"><button class="but" style="background-color:#b9c1cc;">Sign Up</button></a>
                                  </center>
                              </div>
                      </div>
                  </div>
                  </div>
              </div>
          </div>
   </div>
   </body>
</html>
<script type="text/javascript" src="design\js\page_animation.js"></script>
<script>
   $(document).ready(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
  document.getElementById("loads").style.display="block";
  document.getElementById("cont").style.display="none";
  setTimeout("hide()", 2000);
});
function hide() {
    document.getElementById("loads").style.display="none";
    document.getElementById("cont").style.display="block";
}
</script> 