<?php
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <fourmex.iot.c038.c036.c046.c126@gmail.com>' . "\r\n";
$to = $email;
$subject = "Order Confirmed";
$message = "<h3>Dear $user_name,</h3>"
        . "<h5>You Have Order Has Successfully Placed</h5>"
        . "<h5>Order Id : ".strtoupper($orderid)."</h5>"
        . "<a href='http://localhost/IOT_PROJECT/order_view.php?id=$orderid'>Click Here to View It</a>"
       ; 
ini_set("SMTP","ssl://smtp.gmail.com");
ini_set("smtp_port","587");
mail($to,$subject,$message,$headers);
require 'email_wallet.php';
require 'email_order_delivered.php';
?>

