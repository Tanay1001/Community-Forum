<style>
    .nav>li>a{
         color: rgb(255,255,255);
         }
         .nav>li>a:focus, .nav>li>a:hover{
         text-decoration: none;
         background-color: rgba(0,0,0,0.2);
         background-size: 50px;
         margin-top: 5px; margin-bottom: 5px;
         padding-top: 5px; 
         border-radius: 100px;
         color: rgb(255,255,255);
         text-shadow: 5px 5px rgb(0,0,0,0.2);
         }
         .icon-bar{
         background-color: rgb(255,255,255);
         }
</style>
<div class="navbar " style="background: #f8f8ff; border: 0; padding-top:20px; box-shadow: 10px 5px 5px 5px rgba(0,0,0,0.2);">
            <div class="container">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle" style="background-color: rgb(0,0,0,0.2);" data-toggle="collapse" data-target="#myNavbar">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>                        
                  </button>
                   <b><a class="navbar-brand" style="font-size: 24px;color: rgb(0,0,0); text-shadow: 5px 5px rgb(0,0,0,0.2)" href="index_store.php">Forumex Store</a></b>
               </div>
               <div class="collapse navbar-collapse" style="border:0;" id="myNavbar">
                   <ul class="nav navbar-nav navbar-right">
                     <li><a href = "../home.php?answered" style="color: rgb(0,0,0); ">Go Back to Fourm</a></li>
                      <li><a href = "myorder.php" style="color: rgb(0,0,0); ">My Order</a></li>
                     <li><a href="cart.php" style="color: rgb(0,0,0); ">Cart</a></li>
                     <li><a href="../logout_script.php" style="color: rgb(0,0,0); ">Logout</a></li>
                  </ul>
               </div>
            </div>
</div>