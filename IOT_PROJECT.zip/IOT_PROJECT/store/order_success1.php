<?php
   session_start();
   require("../includes/connection.php");
   if (!isset($_SESSION['user_email'])) {
       header('location:  ../home.php?answered');
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
       <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <script type="text/javascript" src="design/js/validation.js" ></script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Order Success | Forumex</title>
      <style>
              #loads{
               background: url('../design/image/order_place.gif') no-repeat center center;
               position: absolute;
               top: 0;
               left: 0;
               height: 100vh;
               width: 100%;
               z-index: 9999999;
          }         
      </style>
   </head>
   <body>
              <?php
if(isset($_GET['id'])){
    $oid = $_GET['id'];
       $sel = "select * from order_user where id = '$oid'";
       $sel = mysqli_query($con, $sel) or die (mysqli_error($con));
       if(mysqli_num_rows($sel) == 1){
       ?>
        <div id="loads"></div>
       <?php } else {
           echo "<script>alert('Oops! Page Not Found')</script>";
    echo ("<script>location.href='index_store.php'</script>");
       }
} else {
    echo "<script>alert('Error 404! Page Not Found')</script>";
    echo ("<script>location.href='index_store.php'</script>");
}
?>
   </body>
</html>
<script>
window.setTimeout(function() {
    window.location = 'myorder.php';
  }, 6000);
</script>
