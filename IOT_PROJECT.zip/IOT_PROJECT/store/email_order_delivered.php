<?php
   function giftidgenerator(){
       require("../includes/connection.php");
       $orderid = bin2hex(random_bytes(5));
       $querys = "SELECT * FROM order_user WHERE gift_card_id='$orderid'";
       $results = mysqli_query($con, $querys)or die(mysqli_error($con));
       if(mysqli_num_rows($results) > 0){
          orderidgenerator();
       } else {
           return $orderid;    
       }
   }
   $gift_card_id = giftidgenerator();
   $update = "update order_user set gift_card_id = '$gift_card_id' where id = '$orderid'";
   $update = mysqli_query($con, $update) or die(mysqli_error($con));
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <fourmex.iot.c038.c036.c046.c126@gmail.com>' . "\r\n";
$to = $email;
$subject = "Order Delivered";
$message = "<h3>Dear $user_name,</h3>"
        . "<h5>You Have Order Has Successfully Delivered</h5>"
        . "<h5>Order Id : ".strtoupper($orderid)."</h5>"
        . "<h5>The Paytm Gift Card is worth $sum_money Rupees</h5>"
        . "<h5>Gift Card Id : ".strtoupper($gift_card_id)."</h5>"
       ; 
ini_set("SMTP","ssl://smtp.gmail.com");
ini_set("smtp_port","587");
mail($to,$subject,$message,$headers);
?>

