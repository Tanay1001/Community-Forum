<?php
   require("../includes/connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:../login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       $sel = "SELECT * FROM users WHERE user_id= '$id'";
       $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
       $row= mysqli_fetch_array($sel1);
       $users_interest = $row['user_interest'];
       $user_name = $row['user_name'];
       $users_bio = $row['user_bio'];
       if( $users_interest == null){
           echo ("<script>location.href='../user_interest_form.php'</script>");
       } elseif ($users_bio == null) {
       echo ("<script>location.href='../user_bio_form.php'</script>");
   }
   if( $email == "admin@fourmex.com"){
       header('location:../admin\admin_index.php');
   }
   }
   function orderidgenerator(){
       require("../includes/connection.php");
       $orderid = bin2hex(random_bytes(4));
       $querys = "SELECT * FROM order_user WHERE id='$orderid'";
       $results = mysqli_query($con, $querys)or die(mysqli_error($con));
       if(mysqli_num_rows($results) > 0){
          orderidgenerator();
       } else {
           return $orderid;    
       }
   }
if(isset($_POST['order_confirm'])){
    $sel = "select * from cart where user_id = '$id'";
    $sel = mysqli_query($con, $sel) or die(mysqli_error($con));
    if(mysqli_num_rows($sel) > 0){
        $orderid = orderidgenerator();
        $insert_order = "insert into order_user(id,user_id) values ('$orderid','$id')";
        $insert_order = mysqli_query($con, $insert_order) or die(mysqli_error($con));
        if($insert_order){
            $sel = "select * from cart where user_id = '$id' order by prod_id asc";
    $sel = mysqli_query($con, $sel) or die(mysqli_error($con));
    $prod_id_arr = array(); $prod_id_qty = array();
    $sum = 0;
    while ($row = mysqli_fetch_array($sel)){
        $prod_id = $row['prod_id'];
        $prod_qty = $row['qty'];
        $prod_id_arr[] = $prod_id;
        $prod_id_qty[] = $prod_qty;
        $sel_prod = "select prod_price from products where id = '$prod_id'";
        $sel_prod = mysqli_query($con, $sel_prod) or die(mysqli_error($con));
        $row_fetch = mysqli_fetch_array($sel_prod);
        $prod_price = $row_fetch['prod_price'];
        $total = $prod_price * $prod_qty;
        $sum += $total;
    }
    $final_prod_id = implode(",", $prod_id_arr);
    $final_prod_qty = implode(",", $prod_id_qty);
    $insert_order_list = "insert into order_list(order_id,prod_id,qty) values('$orderid','$final_prod_id','$final_prod_qty')";
    $insert_order_list = mysqli_query($con, $insert_order_list);
        if($insert_order_list){
            $order_list_id = mysqli_insert_id($con);
            $update_order_user = "update order_user set order_list_id = '$order_list_id',order_value = '$sum' where id = '$orderid'";
            $update_order_user = mysqli_query($con, $update_order_user) or die(mysqli_error_list($con));
            $insert_wallet_received = "insert into wallet_used(user_id,order_id,point) values('$id','$orderid','$sum')";
            $insert_wallet_received = mysqli_query($con, $insert_wallet_received) or die(mysqli_error_list($con));
            if($insert_wallet_received){
                $sel = "select wallet from users where user_id = '$id'";
                $sel = mysqli_query($con, $sel) or die(mysqli_error_list($con));
                $fetch_sel = mysqli_fetch_array($sel);
                $wallet = $fetch_sel['wallet'] - $sum;
                $sel = "update users set wallet = '$wallet' where user_id = '$id'";
                $sel = mysqli_query($con, $sel) or die(mysqli_error_list($con));
                $del = "delete from cart where user_id='$id'";
                $del = mysqli_query($con,$del) or die(mysqli_errno($con));
                $_SESSION['display_message'] = 'True';
                echo ("<script>location.href='order_success1.php?id=$orderid'</script>");
                require 'email_order.php';
            } else {
             $del = "delete from order_user where id='$orderid'";
            $del = mysqli_query($con,$del) or die(mysqli_errno($con));
             $del = "delete from order_list where id='$orderid'";
            $del = mysqli_query($con,$del) or die(mysqli_errno($con));
             echo "<script>alert('Oh No! Failed To Order')</script>";
             echo ("<script>location.href='cart.php'</script>");
            }
        } else {
            $del = "delete from order_user where id='$orderid'";
            $del = mysqli_query($con,$del) or die(mysqli_errno($con));
             echo "<script>alert('Sorry Failed To Order')</script>";
             echo ("<script>location.href='cart.php'</script>"); 
        }
        } else {
            echo "<script>alert('Oops! Failed To Order')</script>";
       echo ("<script>location.href='cart.php'</script>"); 
        }
    } else {
        echo "<script>alert('No Product Present In Cart')</script>";
       echo ("<script>location.href='cart.php'</script>"); 
    }
} else {
    echo "<script>alert('Error 404 Page Not Found')</script>";
       echo ("<script>location.href='../wallet.php'</script>"); 
}
?>