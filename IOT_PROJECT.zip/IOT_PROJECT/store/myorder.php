<?php
   require("../includes/connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:../login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       $sel = "SELECT * FROM users WHERE user_id= '$id'";
       $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
       $row= mysqli_fetch_array($sel1);
       $users_interest = $row['user_interest'];
       $users_bio = $row['user_bio'];
       if( $users_interest == null){
           echo ("<script>location.href='../user_interest_form.php'</script>");
       } elseif ($users_bio == null) {
       echo ("<script>location.href='../user_bio_form.php'</script>");
   }
   if( $email == "admin@fourmex.com"){
       header('location:../admin\admin_index.php');
   }
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="../design\css\bootstrap.css">
      <script type="text/javascript" src="../design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="../design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="../design\css\animate.min.css">
      <script type="text/javascript" src="../design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="../design\css\style.css">
      <link rel="stylesheet" type="text/css" href="../design\css\style_animation.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title><?php echo "Cart | FORUMEX Store"; ?></title>
      <style>
          html{
              scroll-behavior: smooth;
          }
         body{
         margin: 0;
         font-family: 'Arial,sans-serif';
         padding: 0;
         max-width:100%;
         overflow-x: hidden;
         }   
         thead > tr {
             font-size: 20px;
             border-bottom: 1px solid rgb(0,0,0);
         }
         tr>th{
              padding: 15px;
         }
         tr>td{
              font-size: 16px;
             padding: 15px;
             padding-top: 25px;
         }
      </style>
   </head>
   <body>
       <?php  require 'store_header.php'; ?>
       <div class="container" style="padding-top: 25px;">
           <h1>My Orders</h1>
           <div class="row">
               <div class="col-xs-12" style="overflow-x:auto;">
                   <table style="width: 100%; height: auto;">
                       <thead>
                           <tr>
                       <th>Order Id</th>
                       <th>Purchase Date</th>
                       <th>Status</th>
                       <th>View</th>
                           </tr>
                       </thead>
                       <tbody>
                           <tr>
                               <td>
                                   ABCD12HHUW
                               </td>
                               <td>
                                   12/08/31
                               </td>
                               <td>
                                   Processing
                               </td>
                               <td>
                                  View
                               </td>
                           </tr>
                       </tbody>
                   </table>
               </div>
           </div>
       </div>
   </body>
</html>
<script type="text/javascript" src="../design\js\page_animation.js"></script>