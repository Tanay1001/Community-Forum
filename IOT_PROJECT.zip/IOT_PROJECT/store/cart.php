<?php
   require("../includes/connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:../login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       $sel = "SELECT * FROM users WHERE user_id= '$id'";
       $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
       $row= mysqli_fetch_array($sel1);
       $users_interest = $row['user_interest'];
       $users_bio = $row['user_bio'];
       if( $users_interest == null){
           echo ("<script>location.href='../user_interest_form.php'</script>");
       } elseif ($users_bio == null) {
       echo ("<script>location.href='../user_bio_form.php'</script>");
   }
   if( $email == "admin@fourmex.com"){
       header('location:../admin\admin_index.php');
   }
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="../design\css\bootstrap.css">
      <script type="text/javascript" src="../design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="../design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="../design\css\animate.min.css">
      <script type="text/javascript" src="../design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="../design\css\style.css">
      <link rel="stylesheet" type="text/css" href="../design\css\style_animation.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title><?php echo "Cart | FORUMEX Store"; ?></title>
      <style>
          html{
              scroll-behavior: smooth;
          }
         body{
         margin: 0;
         font-family: 'Arial,sans-serif';
         padding: 0;
         max-width:100%;
         overflow-x: hidden;
         }   
         thead > tr {
             font-size: 20px;
             border-bottom: 1px solid rgb(0,0,0);
         }
         tr>th{
              padding: 15px;
         }
         tr>td{
              font-size: 16px;
             padding: 15px;
             padding-top: 25px;
         }
         .update{
             color:rgb(0,0,0);
         }
         .update:hover{
              color:rgb(0,0,0);
             text-decoration: none;
         }
      </style>
   </head>
   <body>
       <?php  require 'store_header.php'; ?>
       <div class="container" style="padding-top: 25px;">
           <?php 
                           $sel = "select * from cart where user_id = '$id' order by prod_id  asc";
                           $sel = mysqli_query($con, $sel)or die(mysqli_error($con));
                           if(mysqli_num_rows($sel) != 0) {
         ?>
           <div class="row">
              <h1>Your Cart</h1>
               <div class="col-xs-12" style="overflow-x:auto;">
                   <table style="width: 100%; height: auto;">
                       <thead>
                           <tr>
                       <th>Product Name</th>
                       <th>Quantity</th>
                       <th>Points</th>
                       <th>Delete</th>
                           </tr>
                       </thead>
                       <tbody>  
                           <?php 
                           $sum = 0;
                           $sum_money = 0;
                                    while ($row = mysqli_fetch_array($sel)) {
                                        $prod_id = $row['prod_id'];
                                        $qty = $row['qty'];
                                        $sel_prod = "select prod_name,prod_price,prod_money from products where id = '$prod_id'";
                                        $sel_prod = mysqli_query($con, $sel_prod) or die(mysqli_error($con));
                                        $row_fetch = mysqli_fetch_array($sel_prod);
                                        $prod_name = $row_fetch['prod_name'];
                                        $prod_price = $row_fetch['prod_price'];
                                       $total = $prod_price * $qty;
                                       $sum_money += ($qty*$row_fetch['prod_money']);
                                       $sum += $total;
                           ?>
                           <tr>
                               <td>
                                   <?php  echo $prod_name; ?>
                               </td>
                               <td>
                                   <a class="update" href="update.php?id=<?php echo $prod_id; ?>&status='minus'"><span class="glyphicon glyphicon-minus"></span></a>
                                   &nbsp;&nbsp;&nbsp;&nbsp;<?php  echo $qty; ?>&nbsp;&nbsp;&nbsp;&nbsp;
                                   <a class="update" href="update.php?id=<?php echo $prod_id; ?>&status='add'"><span class="glyphicon glyphicon-plus"></span></a>
                               </td>
                               <td>
                                    <?php  echo $total ."( ".$qty." * ".$prod_price. " )"; ?>
                               </td>
                               <td>
                                   <a href="delete.php?id=<?php echo $prod_id; ?>" style="color:rgb(0,0,0);">Delete</a>
                               </td>
                           </tr>
                                    <?php } ?>
                       </tbody>
                   </table>
               </div>
               <div class="col-xs-offset-7 col-xs-5" style="padding-top: 20px; font-size: 16px;">
                   <p><strong>Total</strong> : <?php echo $sum; ?> Points</p>
                   <p><strong>Total Gift Card Value(In Rupees)</strong> : <?php echo $sum_money; ?></p>
                   <?php 
                   $sel_user = "select wallet from users where user_id = '$id'";
                   $sel_user = mysqli_query($con, $sel_user) or die(mysqli_error($con));
                   $sel_user_fetch = mysqli_fetch_array($sel_user);
                   if($sum <= $sel_user_fetch['wallet']) {?>
                   <p><strong>Wallet</strong> : <?php echo $sel_user_fetch['wallet']; ?></p>
                   <form action="order_place.php" method="POST">
                       <button type="submit" class="btn btn-success" name="order_confirm">Place Order</button>
                   </form>
                   <p style="color:rgb(255,0,0);"><?php echo "Order Once Placed Cannot Be Cancelled*"; ?></p>
                   <?php } else { 
                       $dif = $sum - $sel_user_fetch['wallet'];
                       ?>
                   <p><strong>Wallet</strong> : <?php echo $sel_user_fetch['wallet']; ?></p>
                   <p style="color:rgb(255,0,0);"><?php echo "You are short of ".$dif." Points"; ?></p>
                 <?php  } ?>
               </div>
           </div>
            <?php } else { ?>
           <div class="row">
               <div class="col-xs-12">
                   <center><h1>No Product Added</h1></center>
               </div>
           </div>
                           <?php } ?>
       </div>
   </body>
</html>
<script type="text/javascript" src="../design\js\page_animation.js"></script>