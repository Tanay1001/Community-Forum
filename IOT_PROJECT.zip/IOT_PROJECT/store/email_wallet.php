<?php
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <fourmex.iot.c038.c036.c046.c126@gmail.com>' . "\r\n";
$to = $email;
$subject = "Ponints Debited";
$message = "<h3>Dear $user_name,</h3>"
        . "<h5>You Have Used $sum Points</h5>"
        . "<h5>For Order Id : ".strtoupper($orderid)."</h5>"
        . "Updated Wallet Point : $wallet"
       ; 
ini_set("SMTP","ssl://smtp.gmail.com");
ini_set("smtp_port","587");
mail($to,$subject,$message,$headers);
require 'email_order_delivered.php';
?>

