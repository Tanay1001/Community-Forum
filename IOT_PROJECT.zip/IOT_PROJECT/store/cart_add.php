<?php
   require("../includes/connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:../login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       $sel = "SELECT * FROM users WHERE user_id= '$id'";
       $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
       $row= mysqli_fetch_array($sel1);
       $users_interest = $row['user_interest'];
       $users_bio = $row['user_bio'];
       if( $users_interest == null){
           echo ("<script>location.href='../user_interest_form.php'</script>");
       } elseif ($users_bio == null) {
       echo ("<script>location.href='../user_bio_form.php'</script>");
   }
   if( $email == "admin@fourmex.com"){
       header('location:../admin\admin_index.php');
   }
   }
if(isset($_GET['id'])){
    $prod_id = $_GET['id'];
    $sel = "select * from products where id = '$prod_id'";
    $sel = mysqli_query($con, $sel) or die(mysqli_error($con));
    if(mysqli_num_rows($sel) == 1){
    $sel = "select * from cart where user_id = '$id' and prod_id = '$prod_id'";
    $sel = mysqli_query($con, $sel) or die(mysqli_error($con));
    if(mysqli_num_rows($sel) == 0){
        $insert = "insert into cart (prod_id,qty,user_id) values ('$prod_id','1','$id')";
        $insert = mysqli_query($con, $insert) or die(mysqli_error($con));
        if($insert){
            echo ("<script>location.href='index_store.php#gift_card'</script>");
        } else {
            echo ("<script>alert('Failed to Add')</script>");
            echo ("<script>location.href='index_store.php#gift_card'</script>");
        }
    } else {
        echo ("<script>alert('Faild to Add')</script>");
        echo ("<script>location.href='index_store.php#gift_card'</script>");
    }
 } else {
     echo ("<script>alert('Filed to Add')</script>");
     echo ("<script>location.href='index_store.php#gift_card'</script>");
 }
}
?>