<?php
   require("../includes/connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:../login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       $sel = "SELECT * FROM users WHERE user_id= '$id'";
       $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
       $row= mysqli_fetch_array($sel1);
       $users_interest = $row['user_interest'];
       $users_bio = $row['user_bio'];
       if( $users_interest == null){
           echo ("<script>location.href='../user_interest_form.php'</script>");
       } elseif ($users_bio == null) {
       echo ("<script>location.href='../user_bio_form.php'</script>");
   }
   if( $email == "admin@fourmex.com"){
       header('location:../admin\admin_index.php');
   }
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="../design\css\bootstrap.css">
      <script type="text/javascript" src="../design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="../design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="../design\css\animate.min.css">
      <script type="text/javascript" src="../design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="../design\css\style.css">
      <link rel="stylesheet" type="text/css" href="../design\css\style_animation.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title><?php echo "FORUMEX Store"; ?></title>
      <style>
          html{
              scroll-behavior: smooth;
          }
         body{
         margin: 0;
         font-family: 'Arial,sans-serif';
         padding: 0;
         max-width:100%;
         overflow-x: hidden;
         }     
         .nav>li>a{
         color: rgb(255,255,255);
         }
         .nav>li>a:focus, .nav>li>a:hover{
         text-decoration: none;
         background-color: rgba(0,0,0,0.2);
         background-size: 50px;
         margin-top: 5px; margin-bottom: 5px;
         padding-top: 5px; 
         border-radius: 100px;
         color: rgb(255,255,255);
         text-shadow: 5px 5px rgb(0,0,0,0.2);
         }
         .icon-bar{
         background-color: rgb(255,255,255);
         }
         #content{
              color:rgb(255,255,255);
         }
         h1,h2{
             font-family: cursive;
         }
         .but{
          width: 150px;
         margin-top: 10px;
         padding: 5px 10px 5px 10px;
         color:rgb(255,255,255);
         background-color: rgb(0,0,0);
         }
         button > a:hover{
             text-decoration: none;
         }
         @media(min-width:300px){
              #content > h1{
             font-size: 36px;
         }
         }
         @media(min-width:500px){
              #content > h1{
             font-size: 44px;
         }
         }
         @media(min-width:750px){
              #content > h1{
             font-size: 60px;
         }
         }
      </style>
   </head>
   <body>
       <div class="container-fluid" style="background-color: #65a6ff; height:100vh;">
         <div class="navbar " style="background: transparent; border: 0; padding-top:20px;">
            <div class="container">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle" style="background-color: rgb(0,0,0,0.2);" data-toggle="collapse" data-target="#myNavbar">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>                        
                  </button>
                  <b><a class="navbar-brand" style="font-size: 36px;color: rgb(255,255,255); text-shadow: 5px 5px rgb(0,0,0,0.2)" href="#">Forumex Store</a></b>
               </div>
               <div class="collapse navbar-collapse" style="border:0;" id="myNavbar">
                  <ul class="nav navbar-nav navbar-right">
                     <li><a href = "../home.php?answered">Go Back to Fourm</a></li>
                      <li><a href = "myorder.php">My Order</a></li>
                     <li><a href="cart.php" >Cart</a></li>
                     <li><a href="../logout_script.php">Logout</a></li>
                  </ul>
               </div>
            </div>
         </div>
           <div class="container zoom" style="">
            <center>
                <div class="container" style="padding-top: 140px;">
                    <div class="row"> 
                        <div class="col-xs-12" id="content">
                  <h1>Welcome to Forumex Store</h1>
                  <h3 style="font-size: 20px;">Redeem Your Points</h3>
                  <a  href="#gift_card"><button class="but" >Redeem Now</button></a>
                        </div>
                    </div>
               </div>
            </center>
         </div>
       </div>
          <div class="container zoom" style="">
            <center>
                <div class="container" style="padding-top: 140px; padding-bottom: 100px; height: 100vh;">
                    <div class="row" id="gift_card">
                        <h1>Our Products</h1>
                        <div class="col-xs-12 col-sm-4">
                            <div class="panel">
                                <div class="panel-body">
                                    <img src="../design/image_store/Paytm-gift-card.jpg" alt="" style="width: 100%; height: auto;"/>
                                    <p style="padding-top:20px;font-size:16px;;">250 Rupees Gift Card</p>
                                </div>
                                <div class="panel-footer" style="border-top: 1px solid #f8f8ff">
                                    <p style="font-size:16px;">1000 Points</p>
                                    <?php 
                                    $sel = "select * from cart where user_id='$id' and prod_id = '1'";
                                    $sel = mysqli_query($con, $sel);
                                    if(mysqli_num_rows($sel) == 1){
                                    ?>
                                    <p><button class="btn btn-primary" disabled>Added To Cart</button></p>
                                    <?php } else { ?>
                                    <p><button class="btn btn-primary"><a href="cart_add.php?id=1" style="color:rgb(255,255,255);">Add To Cart</a></button></p>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4">
                            <div class="panel">
                                <div class="panel-body">
                                    <img src="../design/image_store/Paytm-gift-card.jpg" alt="" style="width: 100%; height: auto;"/>
                                    <p style="padding-top:20px;font-size:16px;;">500 Rupees Gift Card</p>
                                </div>
                                <div class="panel-footer" style="border-top: 1px solid #f8f8ff">
                                    <p style="font-size:16px;">2000 Points</p>
                                    <?php 
                                    $sel = "select * from cart where user_id='$id' and prod_id = '2'";
                                    $sel = mysqli_query($con, $sel);
                                    if(mysqli_num_rows($sel) == 1){
                                    ?>
                                    <p><button class="btn btn-primary" disabled>Added To Cart</button></p>
                                    <?php } else { ?>
                                    <p><button class="btn btn-primary"><a href="cart_add.php?id=2" style="color:rgb(255,255,255);">Add To Cart</a></button></p>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-4">
                            <div class="panel">
                                <div class="panel-body">
                                    <img src="../design/image_store/Paytm-gift-card.jpg" alt="" style="width: 100%; height: auto;"/>
                                    <p style="padding-top:20px;font-size:16px;;">1000 Rupees Gift Card</p>
                                </div>
                                <div class="panel-footer" style="border-top: 1px solid #f8f8ff">
                                    <p style="font-size:16px;">4000 Points</p>
                                    <?php 
                                    $sel = "select * from cart where user_id='$id' and prod_id = '3'";
                                    $sel = mysqli_query($con, $sel);
                                    if(mysqli_num_rows($sel) == 1){
                                    ?>
                                    <p><button class="btn btn-primary" disabled>Added To Cart</button></p>
                                    <?php } else { ?>
                                    <p><button class="btn btn-primary"><a href="cart_add.php?id=3" style="color:rgb(255,255,255);">Add To Cart</a></button></p>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
            </center>
                    </div>
   </body>
</html>
<script type="text/javascript" src="../design\js\page_animation.js"></script>