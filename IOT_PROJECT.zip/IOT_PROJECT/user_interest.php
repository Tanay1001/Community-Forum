<?php
   if(isset($_POST['submit_interest'])){
        $interest_temp = $_POST['interest'];
        if(count($interest_temp) >= 3){
            $interest = '';
            foreach ($interest_temp as $value) {
                $interest = $interest.$value.',';
            }
            $sel = "UPDATE users SET user_interest = '$interest' WHERE user_id = '$id'";
            $check=mysqli_query($con, $sel) or die(mysqli_error($con));
            if($check){
                echo "<script>alert('Updated')</script>"; 
               echo ("<script>location.href='account_details.php?user_id=$id'</script>");
            } else {
              echo "<script>alert('Try Again')</script>"; 
              echo ("<script>location.href='account_details.php?user_id=$id'</script>");
            }
        } else {
          echo "<script>alert('Please Choose Atleast 3')</script>";  
          echo ("<script>location.href='account_details.php?user_id=$id'</script>");
        }
    }
   ?>
<br><span style="font-weight: 700;">Interest: </span>
<div class="change_show"><div style="word-wrap:break-word;display:inline;"><?php echo $user_interest; ?></div>
   <?php if(isset($_SESSION['user_email']) && $_SESSION['user_email'] == $num['user_email']){ ?> 
    <a data-target="#interest" data-toggle="modal" class="change">Change Interest</a>
       <div class="modal fade" id="interest">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Change Your Interest</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                  <h3>Choose Your Interest</h3>
                  <p>Min 3 Choices:</p>
                  <form style="width: auto;"onsubmit="return Validate_interest()" method="POST">
                     <div class="btn-group" data-toggle="buttons">
                        <label class="btn" style=" border: 1px solid;border-radius: 20px;">
                        <input type="checkbox" name="interest[]" value="Technology">Technology
                        </label>
                     </div>
                     <div class="btn-group" data-toggle="buttons">
                        <label class="btn" style=" border: 1px solid;border-radius: 20px;">
                        <input type="checkbox" name="interest[]" value="Studies">Studies
                        </label>
                     </div>
                     <div class="btn-group" data-toggle="buttons">
                        <label class="btn" style=" border: 1px solid;border-radius: 20px;">
                        <input type="checkbox" name="interest[]" value="Sports">Sports
                        </label>
                     </div>
                     <br><br>
                     <div class="btn-group" data-toggle="buttons">
                        <label class="btn" style=" border: 1px solid;border-radius: 20px;">
                        <input type="checkbox" name="interest[]" value="Finance">Finance
                        </label>
                     </div>
                     <div class="btn-group" data-toggle="buttons">
                        <label class="btn" style=" border: 1px solid;border-radius: 20px;">
                        <input type="checkbox" name="interest[]" value="Music">Music
                        </label>
                     </div>
                     <div class="btn-group" data-toggle="buttons">
                        <label class="btn" style=" border: 1px solid;border-radius: 20px;">
                        <input type="checkbox" name="interest[]" value="Dance">Dance
                        </label>
                     </div>
                     <br><br>
                     <div class="btn-group" data-toggle="buttons">
                        <label class="btn" style=" border: 1px solid;border-radius: 20px;">
                        <input type="checkbox" name="interest[]" value="Business">Business
                        </label>
                     </div>
                     <br><br>
                     <input type="submit" class="logbtn" name="submit_interest" id ="submit" value="Submit">
                  </form>
               </center>
            </div>
         </div>
      </div>
   </div>
      <?php } ?> 
</div>

<script>
   function Validate_interest(){
   if(document.querySelectorAll('input[type="checkbox"]:checked').length < 3){
       alert("Please Select Minimum 3*");
       return false;
   }
   }
</script>