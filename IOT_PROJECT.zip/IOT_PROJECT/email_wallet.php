<?php
$question_user_email = "select * from users where user_id ='$id'";
$question_user_email = mysqli_query($con, $question_user_email);
$question_user_email_fetch = mysqli_fetch_array($question_user_email);
$user_email_send = $question_user_email_fetch['user_email'];
$user_name_send =  $question_user_email_fetch['user_name'];
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <fourmex.iot.c038.c036.c046.c126@gmail.com>' . "\r\n";
$to = $user_email_send;
$subject = "Points Creditied";
$message = "<h3>Dear $user_name_send,</h3>"
        . "<h5>Your Wallet Has Been Creditied With $spoint</h5>"
        . "<h5>Total Points: $total</h5>"
       ; 
ini_set("SMTP","ssl://smtp.gmail.com");
ini_set("smtp_port","587");
mail($to,$subject,$message,$headers);
?>