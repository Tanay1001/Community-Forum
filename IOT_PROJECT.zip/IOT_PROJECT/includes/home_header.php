<style>
   .nav>li>a{
   color: rgb(0,0,0);
   }
   .nav>li>a:focus, .nav>li>a:hover{
   text-decoration: none;
   background-color: rgba(0,0,0,0.2);
   background-size: 50px;
   margin-top: 5px; margin-bottom: 5px;
   padding-top: 5px; 
   border-radius: 100px;
   color: rgb(255,255,255);
   text-shadow: 5px 5px rgb(0,0,0,0.2);
   }
   .icon-bar{
   background-color: rgb(255,255,255);
   }
   .dropdown-toggle{
   text-decoration: none;
   background-size: 50px;
   margin: 10px;
   padding-top: 5px; 
   color: rgb(0,0,0);
   }
   .dropdown-toggle:focus, .dropdown-toggle:hover{
   text-decoration: none;
   background-color: rgba(0,0,0,0.2);
   background-size: 50px;
   margin: 10px; 
   padding: 5px; 
   border-radius: 100px;
   color: rgb(255,255,255);
   text-shadow: 5px 5px rgb(0,0,0,0.2);
   }
   .dropdown-menu > li{
   padding: 10px;
   width: auto;
   }
</style>
<div class="navbar navbar-fixed-top" style="background: #f8f8ff; border: 0; box-shadow: 10px 5px 5px 5px rgba(0,0,0,0.2);">
   <div class="container">
      <div class="navbar-header">
         <button type="button" class="navbar-toggle" style="background-color: rgb(0,0,0,0.2);" data-toggle="collapse" data-target="#myNavbar">
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>                        
         </button>
         <b><a class="navbar-brand" style="color: black; text-shadow: 5px 5px rgb(0,0,0,0.2)" href="index.php">Forumex</a></b>
      </div>
      <div class="collapse navbar-collapse" style="border:0" id="myNavbar">
         <ul class="nav navbar-nav navbar-right">
            <?php
               if (isset($_SESSION['user_email'])) {
                   ?>
             <?php if($_SERVER['PHP_SELF'] != "/IOT_PROJECT/help.php"){?>
            <li class="dropdown">
               <div class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-search"></span> Search</div>
               <ul class="dropdown-menu">
                  <li class="fourm_list">
                      <form class="dropdown-item form-inline" style=" width: 400px;" method="GET" action="search.php">
                          <input type="text" class="form-control" name="search_text" placeholder="Search Your Question" style="display: inline;width:80%;" required>
                         <button type="submit" style="background:transparent; border:none; font-size: 20px; display: inline;width:10%;"><span class="glyphicon glyphicon-search"></span></button>
                     </form>
                  </li>
               </ul>
            </li>
             <?php }?>
            <li class="dropdown">
               <div class="dropdown-toggle" data-toggle="dropdown">Forum<span class="glyphicon glyphicon-triangle-bottom"></span></div>
               <ul class="dropdown-menu">
                  <li><a  data-target="#questions-form" data-toggle="modal" > Ask a Question</a></li>
                  <li class="fourm_list"><a class="dropdown-item" href = "home.php?answered" > Answered Questions</a></li>
                  <li class="fourm_list"><a class="dropdown-item" href = "home.php?not_ans" > Not Answered Questions</a></li>
                  <li class="fourm_list"><a class="dropdown-item" href = "home.php?your_question" > Your Questions</a></li>
                  <li class="fourm_list"><a class="dropdown-item" href = "home.php?your_ans" > Your Answer</a></li>
               </ul>
            </li>
            <li class="dropdown">
               <div class="dropdown-toggle" data-toggle="dropdown">My Account<span class="glyphicon glyphicon-triangle-bottom"></span></div>
               <ul class="dropdown-menu" >
                  <li><a  href = "account_details.php?user_id=<?php echo $_SESSION['user_id']?>" ><span class = "glyphicon glyphicon-user"></span> My Account</a></li>
                  <li><a href = "wallet.php" ><span class="glyphicon glyphicon-piggy-bank"></span> Wallet</a></li>
                  <li><a  href = "survey.php" ><span class = "glyphicon glyphicon-tasks"></span> Survey</a></li>
                  <li><a  href = "stats.php" ><span class = "glyphicon glyphicon-signal"></span> Your Stats</a></li>
                  <li><a href = "about.php"><span class = "glyphicon glyphicon-info-sign"></span> About Us</a></li>
               </ul>
            </li>
            <li><a href = "logout_script.php">Logout <span class = "glyphicon glyphicon-log-in"></span></a></li>
            <?php
               } else {
                   ?>
            <li><a href = "about.php"><span class = "glyphicon glyphicon-info-sign"></span> About Us</a></li>
            <li><a href="signup.php" ><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
            <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
            <?php
               }
               ?>
         </ul>
      </div>
   </div>
</div>
<?php require 'question-form.php'; ?>