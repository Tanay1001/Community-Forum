<footer>
    <div style="padding: 10px 10px; background-color: rgb(0,0,0,0.8); color:rgb(255,255,255); bottom: 0; width: 100%;">
        <center>
            <strong>Copyright &copy; Fourmex. All Rights Reserved  |  Contact Us: +91-99887 65543</strong>	
        </center>
    </div>
</footer>