<style>
    .nav>li>a{
        color: rgb(0,0,0);
    }
    .nav>li>a:focus, .nav>li>a:hover{
        text-decoration: none;
        background-color: rgba(0,0,0,0.2);
        background-size: 50px;
        margin-top: 5px; margin-bottom: 5px;
        padding-top: 5px; 
        border-radius: 100px;
        color: rgb(255,255,255);
        text-shadow: 5px 5px rgb(0,0,0,0.2);
    }
    .icon-bar{
        background-color: rgb(255,255,255);
    }
</style>

<div class="navbar navbar-fixed-top" style="background: #f8f8ff; border: 0; box-shadow: 10px 5px 5px 5px rgba(0,0,0,0.2);">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" style="background-color: rgb(0,0,0,0.2);" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            <b><a class="navbar-brand" style="color: black; text-shadow: 5px 5px rgb(0,0,0,0.2)" href="index.php">Fourmex</a></b>
        </div>

        <div class="collapse navbar-collapse" style="border:0" id="myNavbar">

            <ul class="nav navbar-nav navbar-right">
                
                <?php
                if (isset($_SESSION['user_email'])) {
                    ?>
                    <li><a href = "wallet.php" > Wallet</a></li>
                    <li><a href = "survey.php" > Survey</a></li>
                    <li><a href = "about.php"><span class = "glyphicon glyphicon-info-sign"></span> About Us</a></li>
                    <li><a href = "account_details.php?user_id=<?php echo $_SESSION['user_id']?>" ><span class = "glyphicon glyphicon-user"></span> My Account</a></li> 
                    <li><a href = "logout_script.php"><span class = "glyphicon glyphicon-log-in"></span> Logout</a></li>

                    <?php
                } else {
                    ?>
                    <li><a href = "about.php"><span class = "glyphicon glyphicon-info-sign"></span> About Us</a></li>
                    <li><a href="signup.php" ><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>

                    <?php
                }
                ?>
            </ul>
        </div>
    </div>
</div>