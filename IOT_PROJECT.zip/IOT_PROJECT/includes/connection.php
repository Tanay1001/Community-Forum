<?php
$con = mysqli_connect("localhost", "root", "", "fourmex", "3308") or die(mysqli_error($con));
?>