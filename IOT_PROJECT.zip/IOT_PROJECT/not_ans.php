<?php 
$sel = "select * from question where total_answer = 0 order by 	total_visitor desc";
$sel = mysqli_query($con, $sel) or die(mysqli_error($con));
if(mysqli_num_rows($sel) > 0){
$count =0;
?>
<div class="row" id="not_ans">
    <div class="col-xs-12 col-sm-offset-2 col-sm-8">
        <?php while($row= mysqli_fetch_array($sel)){ $count++;?>
        <div class="question-card zoom" id="<?php echo $row['id']; ?>">
            <div class="row" style="display: flex;width:100%; height: 100%;">
            <div class="col-xs-4 col-sm-2 side_question-card">
               <?php echo $row['total_visitor']." Views";?><br>
               <a type="button" value="Share" onclick="Copy(<?php echo $count?>);" style="background-color: transparent; border: none; color: rgb(0,0,0);" >Share</a>
               <input id="url<?php echo $count?>" style="display:none;"value="<?php echo "http://localhost/IOT_PROJECT/answer_view.php?id=".$row['id'];?>">
            </div>
                <div class="col-xs-9 col-sm-10" style=" padding:10px 0px 5px 5px; border-left:1px solid rgb(0,0,0);">
            <p><a href="#answer_modal" data-toggle="modal" data-answer-id="<?php echo $row['id'];?>" style="color:rgb(0,0,0);"><?php echo $row['question'];?></a></p>
                </div>
            </div>
        </div>
        <?php if($count%4 == 0){ ?>
        <div class="add-card zoom" >
            <a href="https://www.amazon.in/" target="_blank"><img src="design/image/add.gif" alt=""/></a>
        </div>
       <?php } ?>
        <?php } ?>
    </div>    
</div>
   <div class="modal fade" id="answer_modal">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Add Answer to the Question</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                   <form id="my-form" action="answer.php" onsubmit="return validation_answer()" method="POST" enctype="multipart/form-data" style="width:100%;">
                       <p id="error_msg" style="color:rgb(255,0,0);"></p>
                       <input type="int" value="" id="qid" name="qid" required style="display:none;">
                     <div>
                        <label for="name_form">Enter Your Answer (Min. 50 Words) :</label><br>
                        <center><textarea name="answer_form" id="answer_form" style="width:100%; height: 200px;" required></textarea>
                        </center>
                     </div>
                       <div class="txtb">
                         <label for="text">Upload Photo</label><br>
			 <input type="file" class="form-control" name="uploadedimage">
                         <span></span>
		     </div>
                     <div style="text-align: center">
                         <center> <input type="submit" name="submit_question_answer" class="logbtn" style="font-size: 18px;" value="Submit Answer"> </center>
                     </div>
                  </form>
               </center>
            </div>
         </div>
      </div>
   </div>
  <?php } else {?>
<div class="row">
      <div class="col-xs-12">
                 <div class="container" style="paddin-top:100px;">
                          <div class="row">
                              <div class="col-xs-12" style="">
                                  <center>
                                  <img src="design/image/emoj.gif" style="width: 50%; padding: 0px;height: 100%; margin: 0px;" alt=""/>
                                  <h1>Oops! No Questions Found</h1>
                                  </center>
                              </div>
                          </div>
                      </div>
            </div>
</div>
   <?php } ?>
<script>
    $('#answer_modal').on('show.bs.modal', function(e) {
    var answer = $(e.relatedTarget).data('answer-id');
    $(e.currentTarget).find('input[id="qid"]').val(answer);
});
function validation_answer(){
    var answerss = document.getElementById('answer_form').value;
    var counts = validate_answers(answerss);
    if(counts >= 50){
        return true;
    } else {
       document.getElementById("error_msg").innerHTML = "Min. 50 Words*"+counts;
        return false;
    }
}
</script>
