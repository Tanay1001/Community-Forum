<style>
.user_profile{
  opacity: 1;
  display: block;
  transition: .5s ease;
  backface-visibility: hidden;
}
.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.image_overlay:hover .user_profile {
  opacity: 0.3;
}

.image_overlay:hover .middle {
  opacity: 1;
}

.text {
  background-color: #39A7F9;
  color: white;
  font-size: 12px;
  padding: 16px 32px;
  border-radius: 10px;
}
</style>
<div class="col-xs-10 col-xs-offset-1 col-sm-offset-0 col-sm-3 image_overlay" style="padding-top:20px;">
    <?php 
    if($user_profile != "None"){
        $path = $user_profile ;
    } else {
        $path = "design/image/no_img_profile.png";
    }
    ?>
    <img 
        <?php 
if(isset($_SESSION['user_email']) && $_SESSION['user_email'] == $num['user_email']){ ?>
        class="user_profile" <?php } ?>
        style="border-radius: 50%; width: 100%;height: 233.33px;" src="<?php echo $path;?>" alt=""/>
      <?php if(isset($_SESSION['user_email']) && $_SESSION['user_email'] == $num['user_email']){ ?>
          <div class="middle">
           <a data-target="#profile" data-toggle="modal" ><button class="text">Upload Profile Photo</button></a>
  </div>
      <?php } ?>
</div>
   <div class="modal fade" id="profile">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Update Profile Picture</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                  <p id="error_message" style="color:rgb(255,0,0); font-size: 12px;"></p>
                  <form id="my-form" style="width:100%;" action="profile.php" method="POST" enctype="multipart/form-data">
                     <div class="txtb">
                         <label for="text">Upload Photo</label><br>
			 <input type="file" class="form-control" name="uploadedimage">
                         <span></span>
		     </div>
                     <div style="text-align: center">
                        <center> <input type="submit" id="submit_profile" name="submit_profile" class="logbtn" value="Upload"> </center>
                     </div>
                  </form>
               </center>
            </div>
         </div>
      </div>
   </div>