<?php
   require("includes/connection.php");
   require ("admin/admin_connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
       $sel = "SELECT * FROM users WHERE user_id= '$id'";
       $sel1 = mysqli_query($con, $sel) or die(mysqli_error($con));
       $row= mysqli_fetch_array($sel1);
       $users_interest = $row['user_interest'];
       $users_bio = $row['user_bio'];
       if( $users_interest == null){
           echo ("<script>location.href='user_interest_form.php'</script>");
       } elseif ($users_bio == null) {
       echo ("<script>location.href='user_bio_form.php'</script>");
   }
   if( $email == "admin@fourmex.com"){
       header('location:admin\admin_index.php');
   }
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <link rel="stylesheet" type="text/css" href="design\css\style_animation.css">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <title>Wallet | Forumex</title>
      <style>
             #loads{
               background: url('design/image/Forumex Loading.gif') no-repeat center center;
               position: absolute;
               top: 0;
               left: 0;
               height: 100%;
               width: 100%;
               z-index: 9999999;
          }
           .content{
         padding-top: 100px;
         padding-bottom: 20px;
         }
         .list_points{
             display: inline-block;
             margin: 10px;
             font-family: 'Arial,sans-serif'; 
         }
                  table{
         width: 100%;
         height: 100%;
         }
         tr,td{
             padding: 20px;
           margin: 20px;
         }
         tr{
           border-bottom: 1px solid black;
         }
         tr:last-child{
             border-bottom: 0px;
         }
         tr:hover{
             background-color: #f8f8ff;
         }
         td{
             font-family: 'Arial,sans-serif'; 
             font-size: 20px;
         }
         .list_points > a{
           color:rgb(0,0,0);
           text-decoration: none;
           padding: 15px 5px 15px 5px;
         }
         .list_points > a:hover{
             background-color: #f8f8ff;
         }
          @media(min-width : 300px){
              .list_points{
                  font-size: 14px;
              }
          }
          @media(min-width:500px){
            .list_points{
                  font-size: 18px;
              }
          }
      </style>
   </head>
   <body style="background-color:rgb(255,255,255);">
      <?php
         require 'includes/home_header.php';
          ?>
        <div id="loads"></div>
        <div class="content" id="main">
           <div class="container">
               <div class="row zoom">
                   <div class="col-xs-12" style="border-bottom:1px solid rgb(0,0,0);">
                       <?php 
                       $sum = 0;
                       $neg_sum = 0 ;
                       $sel = "select * from wallet_received where user_id = '$id'";
                       $sel = mysqli_query($con, $sel) or die(mysqli_error($con));
                       while($result = mysqli_fetch_array($sel)){
                           $sum = $sum + $result['point'];
                       }
                       $sel = "select * from wallet_used where user_id = '$id'";
                       $sel = mysqli_query($con, $sel) or die(mysqli_error($con));
                       while($result = mysqli_fetch_array($sel)){
                           $neg_sum = $neg_sum + $result['point'];
                       }
                       $final_sum = $sum - $neg_sum;
                       $sel = "update users SET wallet = '$final_sum' where user_id = '$id'";
                       $sel = mysqli_query($con, $sel) or die(mysqli_error($con));
                       ?>
                       <h2 style="font-family: 'Arial,sans-serif'; font-size: 36px;">Points : <?php echo $final_sum;?>&nbsp;&nbsp;&nbsp;
                           <a href="store/index_store.php" target="_blank" style="color:rgb(0,0,0); font-size: 16px;">Redeem Points</a></h2>
                   </div>
                   <div class="col-xs-12">
                       <h2 style="font-family: 'Arial,sans-serif'; font-size: 25px;">Wallet History</h2>
                   </div>
                   <div class="col-xs-12" id="nav">
                       <ul id="wallet_history" style="list-style-type:none;">
                           <li class="list_points"><a href="#dis1">Points Received</a></li>
                           <li class="list_points"><a href="#dis2">Points Used</a></li>
                       </ul>
                   </div>
                   <div class="col-xs-12 toggle" id="dis1"   style=" padding: 20px;height: 100%;">
                       <?php require 'points_received.php'; ?>
                   </div>
                   <div class="col-xs-12 toggle" id="dis2"  style=" padding: 20px; height: 100%; display: none;">
                       <?php require 'points_used.php'; ?>
                   </div>
               </div>
           </div>
       </div>
   </body>
</html>
<script type="text/javascript" src="design\js\page_animation.js"></script>
<script>
     $(document).ready(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
  document.getElementById("loads").style.display="block";
  document.getElementById("main").style.display="none";
  setTimeout("hide()", 2000);
});
function hide() {
    document.getElementById("loads").style.display="none";
    document.getElementById("main").style.display="block";
}
    $("#wallet_history a").click(function(e){
    e.preventDefault();
    $(".toggle").hide();
    var toShow = $(this).attr('href');
    $(toShow).show();
});
</script>