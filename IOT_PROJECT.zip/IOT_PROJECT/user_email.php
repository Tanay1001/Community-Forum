<?php
   if(isset($_POST['submit_email'])){
       $password = $_POST['password'];
       $password = md5($password);
       $nemail = $_POST['email'];
       $nemail = mysqli_real_escape_string($con, $nemail);
       $regex_email = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/";
       if((!preg_match($regex_email, $nemail))){
           echo "<script>alert('Enter Valid Email')</script>";
       } else {
          $sel = "select * from users where user_email = '$email' and user_password='$password'";
          $sel = mysqli_query($con, $sel);
          if(mysqli_num_rows($sel) == 1){
               if($nemail == $email){
                echo "<script>alert('Email-Id Cannot be same as earlier')</script>";
           } else {
             $select="select user_email from users where user_email = '$nemail' ";
             $result = mysqli_query($con, $select) or die($mysqli_error($con));
             $rows0 = mysqli_fetch_array($result);
             if($rows0 != 0){
                 echo "<script>alert('Email-ID Already Exists')</script>";
             } else {
             $select = "update users SET user_email = '$nemail' where user_id = '$id' ";
             $result = mysqli_query($con, $select) or die($mysqli_error($con));
             if($result){
                $_SESSION['user_email'] = $nemail;
                echo "<script>alert('Email Updated')</script>";
                echo "<script>self.location='account_details.php?user_id=$id'</script>";
             } else {
             echo "<script>alert('Try Again')</script>";    
             echo "<script>self.location='account_details.php?user_id=$id'</script>";
             }
             }
           }
          } else {
              echo "<script>alert('Enter Correct Password')</script>";
              echo "<script>self.location='account_details.php?user_id=$id'</script>";
          }
       }
   }
   ?>
<br><span style="font-weight: 700;">Email:&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</span>
<div class="change_show"><div style="display:inline;"><?php echo $users_email; ?></div>
<a data-target="#email" data-toggle="modal" class="change">Change Email</a>
</div>
   <div class="modal fade" id="email">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"> &times;</button>
               <center>
                  <h3><strong>Change Your E-Mail</strong></h3>
               </center>
            </div>
            <div class="modal-body">
               <center>
                  <p id="error_message" style="color:rgb(255,0,0); font-size: 12px;"></p>
                  <form  method="POST">
                      <div class="txtb">
                        <label for="name_form">Enter Your Current Password</label><br>
                        <input type="password" name="password" id="password" required  >
                        <span></span>
                     </div>
                     <div class="txtb">
                        <label for="name_form">Enter Your New E-Mail</label><br>
                        <input type="text" name="email" id="email" pattern="[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$" required  >
                        <span></span>
                     </div>
                     <div style="text-align: center">
                        <center> <input type="submit" id="submit_email" name="submit_email" class="logbtn" value="Change Email"> </center>
                     </div>
                  </form>
               </center>
            </div>
         </div>
      </div>
   </div>
