<!DOCTYPE html>
<html>
   <head>
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="UTF-8">
      <style>
          #loads{
               background: url('design/image/Forumex Loading.gif') no-repeat center center;
               position: absolute;
               top: 0;
               left: 0;
               height: 100%;
               width: 100%;
               z-index: 9999999;
          }
      </style>
   </head>
   <body>
   <div id="loads"></div>
       <div id="info"> 
           <?php 
if(isset($_GET['token'])){
    session_start();
    require("includes/connection.php");
    $token = $_GET['token'];
    $sel = "SELECT * FROM users WHERE token='$token' AND user_status='Inactive'";
    $sel = mysqli_query($con, $sel)or die(mysqli_error($con));
    if(mysqli_num_rows($sel) != 0){
        $update = "update users set user_status = 'Active' WHERE token='$token'";
        $update = mysqli_query($con, $update)or die(mysqli_error($con));
        if($update){
            $sel = "SELECT * FROM users WHERE token='$token' AND user_status='Active'";
            $sel = mysqli_query($con, $sel)or die(mysqli_error($con));
            $row = mysqli_fetch_array($sel);
            $email = $row['user_email'];
            $_SESSION['user_email'] = $row['user_email'];
            $_SESSION['user_id'] = $row['user_id'];
             if($email == "admin@fourmex.com"){
                 echo ("<script>location.href='admin\admin_index.php'</script>");
     } else {
         echo ("<script>location.href='home.php?answered'</script>");
     }
        } else {
            
        }
    } else {
        echo "<center><h1 style='padding-top:100px;'>Oops! Page Not Found</h1></center>";
    }
} else {
    echo "<center><h1 style='padding-top:100px;'>Page Not Found</h1></center>";
}

?>
     </div>
   </body>
</html>
<script>
   $(document).ready(function() {
 // executes when complete page is fully loaded, including all frames, objects and images
  document.getElementById("loads").style.display="block";
  document.getElementById("info").style.display="none";
  setTimeout("hide()", 3000);
});
function hide() {
    document.getElementById("loads").style.display="none";
    document.getElementById("info").style.display="block";
}
</script> 