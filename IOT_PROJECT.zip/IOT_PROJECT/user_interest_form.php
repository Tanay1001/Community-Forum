<?php
   require("includes/connection.php");
   session_start();
   if (!isset($_SESSION['user_email'])) {
       header('Location:login.php');
   } else {
       $email = $_SESSION['user_email'];
       $id = $_SESSION['user_id'];
   }
    $error = null;
   if(isset($_POST['submit'])){
        $interest_temp = $_POST['interest'];
        if(count($interest_temp) >= 3){
            $interest = '';
            foreach ($interest_temp as $value) {
                $interest = $interest.$value.',';
            }
            $sel = "UPDATE users SET user_interest = '$interest' WHERE user_id = '$id'";
            $check=mysqli_query($con, $sel) or die(mysqli_error($con));
            if($check){
               echo ("<script>location.href='home.php?answered'</script>");
            } else {
               $error = "Try Again"; 
            }
        } else {
          $error = "Please Choose Atleast 3";  
        }
    }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" type="text/css" href="design\css\bootstrap.css">
      <script type="text/javascript" src="design\js\jquery-3.5.1.min.js"></script>
      <script type="text/javascript" src="design\js\bootstrap.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\animate.min.css">
      <script type="text/javascript" src="design\js\jquery.waypoints.js"></script>
      <link rel="stylesheet" type="text/css" href="design\css\style.css">
      <meta charset="UTF-8">
      <title>Forumex</title>
      <style>
         .btn{
         border: 1px solid;
         border-radius: 20px;
         }
         .container{
         opacity: 0;
         }
         .container.animate__zoomIn{
         opacity: 1;
         animation-duration: 1s;
         }
      </style>
   </head>
   <body style="background-color: rgb(255,255,255); padding-top: 100px;">
      <center>
         <h1 style="text-shadow: 5px 5px rgb(0,0,0,0.2); font-weight:bold;">Forumex</h1>
      </center>
      <div class="container">
         <center>
            <h3>Choose Your Interest</h3>
            <p>Min 3 Choices:</p>
            <p id ="message" style="color:rgb(255,0,0);"><?php echo $error; ?></p>
            <form onsubmit="return doValidate()" method="POST">
               <div class="btn-group" data-toggle="buttons">
                  <label class="btn">
                  <input type="checkbox" name="interest[]" value="Technology">Technology
                  </label>
               </div>
               <div class="btn-group" data-toggle="buttons">
                  <label class="btn">
                  <input type="checkbox" name="interest[]" value="Studies">Studies
                  </label>
               </div>
               <div class="btn-group" data-toggle="buttons">
                  <label class="btn">
                  <input type="checkbox" name="interest[]" value="Sports">Sports
                  </label>
               </div>
               <br><br>
               <div class="btn-group" data-toggle="buttons">
                  <label class="btn">
                  <input type="checkbox" name="interest[]" value="Finance">Finance
                  </label>
               </div>
               <div class="btn-group" data-toggle="buttons">
                  <label class="btn">
                  <input type="checkbox" name="interest[]" value="Music">Music
                  </label>
               </div>
               <div class="btn-group" data-toggle="buttons">
                  <label class="btn">
                  <input type="checkbox" name="interest[]" value="Dance">Dance
                  </label>
               </div>
               <br><br>
               <div class="btn-group" data-toggle="buttons">
                  <label class="btn">
                  <input type="checkbox" name="interest[]" value="Business">Business
                  </label>
               </div>
               <br><br>
               <input type="submit" class="logbtn" name="submit" id ="submit" value="Submit">
            </form>
         </center>
      </div>
   </body>
</html>
<script>
   function doValidate(){
    if(document.querySelectorAll('input[type="checkbox"]:checked').length >= 3){
        return true;
    } else{
        document.getElementById("message").innerHTML = "Please Select Minimum 3*";
        return false;
    }
   }
   
   $(document).ready(function () {
       $('.container').waypoint(function (direction) {
           $('.container').addClass('animate__zoomIn');
       }, {
           offset: '100%'
       });
   });
</script>