<div class="col-xs-12 col-sm-offset-1 col-sm-10 col-md-offset-1 col-md-9" style="padding-top: 20px;">
    <p style="text-align:center; font-size: 20px;">
        <a  href="help.php" target="_blank" style="color:rgb(0,0,0);">
            Need Any Help,Click Here
        </a>
    </p> 
</div>