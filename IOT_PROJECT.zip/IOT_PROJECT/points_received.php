 <?php
$sel = "select * from wallet_received where user_id = '$id' order by id desc";
$sel = mysqli_query($con, $sel) or die(mysqli_error($con));
if(mysqli_num_rows($sel) == 0){ ?>
<div class="row">
      <div class="col-xs-12">
                 <div class="container" style="paddin-top:100px;">
                          <div class="row">
                              <div class="col-xs-12" style="">
                                  <center>
                                  <img src="design/image/emoj.gif" style="width: 30%; height: 50%;" alt=""/>
                                  <h1>Oops! No Points Credited</h1>
                                  </center>
                              </div>
                          </div>
                      </div>
            </div>
</div>
<?php } else {
?>
<table>
    <tbody>
        <?php
        while ($result = mysqli_fetch_array($sel)){
    $surveyid = $result['survey_id'];
    $view = $result['view_id'];
    $point = $result['point'];
    $date = $result['datetime'];
    if($view == 0){ 
        $sel1 = "select * from survey_main where survey_id = '$surveyid'";
        $sel1 = mysqli_query($con_survey, $sel1) or die(mysqli_error($con_survey));
        while ($row = mysqli_fetch_array($sel1)) {
            $survey_heading = $row['survey_heading'];
        }
        ?>
        <tr>
            <td style="width: 80%;"><p style="font-weight: bold; color: #16DB93">+ <?php echo $point." Points"; ?></p>
                <p>For Survey&nbsp;<?php echo $survey_heading; ?></p>
            </td>
            <td><p style="font-weight: bold;"><?php echo $date; ?></p></td>
        </tr>
   <?php } elseif ($surveyid == 0) { 
        $sel1 = "select * from answer_view where id = '$view'";
        $sel1 = mysqli_query($con, $sel1) or die(mysqli_error($con));
        while ($row = mysqli_fetch_array($sel1)) {
            $answer_id = $row['answer_id'];
        }
        $sel_answers = "select * from answer where id='$answer_id'";
        $sel_answers = mysqli_query($con, $sel_answers);
        $question_id_fetch = mysqli_fetch_array($sel_answers);
        $question_id = $question_id_fetch['question_id'];
        ?>
        <tr>
            <td><p style="font-weight: bold; color: #16DB93">+<?php echo $point." Points"; ?></p>
                <p><a href="answer_view_main.php?id=<?php echo $answer_id;?>&qid<?php echo $question_id;?>" style="color:rgb(0,0,0);">For Question&nbsp;Answer</a></p>
            </td>
            <td><p style="font-weight: bold;"><?php echo $date; ?></p></td>
        </tr>
   <?php } ?>
<?php } } ?>
    </tbody>
</table>
